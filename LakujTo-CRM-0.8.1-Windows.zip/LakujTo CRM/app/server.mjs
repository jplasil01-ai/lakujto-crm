// LakujTo CRM — server. Běží na počítači v lakovně, okno programu je stránka v prohlížeči,
// telefon na stejné Wi-Fi se připojí přes adresu počítače (vážení barev přes QR).
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { spawn } from 'node:child_process';
import { createRequire } from 'node:module';
import { otevri, transakce } from './db.mjs';
import { novejsi, otisk, rozbalZip, nactiPopis } from './aktualizace.mjs';
import { soucty, ibanZUctu, overIban, formatIban, rozeberUcet, spayd, r2 } from './faktury-vypocty.mjs';

const require = createRequire(import.meta.url);
const qrSvg = require('./vendor/qr.cjs');
const VERZE = '0.8.1';
const KOREN = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.LAKUJTO_PORT || 8765);
const DATA = process.env.LAKUJTO_DATA ||
  (process.platform === 'win32'
    ? path.join(os.homedir(), 'Documents', 'LakujTo CRM')
    : path.join(KOREN, '..', 'data-vyvoj'));
const DB_SOUBOR = path.join(DATA, 'lakujto-crm.db');

let db = otevri(DB_SOUBOR);

// ---------- pomocné ----------
const JEDNOTKY = ['kg', 'l', 'ks', 'bal'];
class Chyba extends Error { constructor(msg, kod = 400) { super(msg); this.kod = kod; } }
const cislo = (v, pole, { povinne = false, min = 0 } = {}) => {
  if (v === undefined || v === null || v === '') { if (povinne) throw new Chyba(`Vyplňte: ${pole}`); return null; }
  const n = Number(String(v).replace(',', '.').replace(/\s/g, ''));
  if (!Number.isFinite(n)) throw new Chyba(`${pole}: zadejte číslo`);
  if (min !== null && n < min) throw new Chyba(`${pole}: nesmí být záporné`);
  return Math.round(n * 1000) / 1000;
};
const text = (v) => (v === undefined || v === null) ? null : (String(v).trim() || null);
const nast = (k) => db.prepare('SELECT hodnota FROM nastaveni WHERE klic=?').get(k)?.hodnota ?? '';

function adresyIP() {
  const out = [];
  for (const [jmeno, seznam] of Object.entries(os.networkInterfaces())) {
    for (const a of seznam || []) {
      if (a.family === 'IPv4' && !a.internal) out.push({ jmeno, ip: a.address });
    }
  }
  const skore = (ip) => ip.startsWith('192.168.') ? 0 : ip.startsWith('10.') ? 1 : ip.startsWith('172.') ? 2 : 3;
  return out.sort((a, b) => skore(a.ip) - skore(b.ip));
}
function adresaProTelefon() {
  const vlastni = nast('telefon_adresa');
  if (vlastni) return vlastni.replace(/\/$/, '');
  const ip = adresyIP()[0]?.ip || 'localhost';
  return `http://${ip}:${PORT}`;
}

// ---------- sklad ----------
const POLOZKA_SQL = `SELECT p.*, d.nazev AS dodavatel, d.email AS dodavatel_email, k.nazev AS kategorie, k.barva AS je_barva
  FROM polozky p LEFT JOIN dodavatele d ON d.id = p.dodavatel_id JOIN kategorie k ON k.id = p.kategorie_id`;
const polozka = (id) => db.prepare(POLOZKA_SQL + ' WHERE p.id=?').get(id);

function ulozPolozku(vstup, id = null) {
  const kat = db.prepare('SELECT * FROM kategorie WHERE id=? AND aktivni=1').get(Number(vstup.kategorie_id) || 0);
  if (!kat) throw new Chyba('Vyberte kategorii');
  const jednotka = text(vstup.jednotka) || kat.jednotka;
  if (!JEDNOTKY.includes(jednotka)) throw new Chyba('Neznámá jednotka');
  const nazev = text(vstup.nazev); if (!nazev) throw new Chyba('Vyplňte název');
  const dod = vstup.dodavatel_id ? Number(vstup.dodavatel_id) : null;
  if (dod && !db.prepare('SELECT 1 FROM dodavatele WHERE id=?').get(dod)) throw new Chyba('Dodavatel neexistuje');
  const hodnoty = {
    kategorie_id: kat.id, nazev, jednotka, dodavatel_id: dod,
    vyrobce: text(vstup.vyrobce), kod_dodavatele: text(vstup.kod_dodavatele),
    ral: text(vstup.ral), povrch: text(vstup.povrch), umisteni: text(vstup.umisteni), poznamka: text(vstup.poznamka),
    baleni: cislo(vstup.baleni, 'Balení'), cena: cislo(vstup.cena, 'Cena'),
    min_zasoba: cislo(vstup.min_zasoba, 'Minimální zásoba') ?? 0, tara: cislo(vstup.tara, 'Váha prázdného obalu') ?? 0,
  };
  return transakce(db, () => {
    if (id) {
      if (!polozka(id)) throw new Chyba('Položka neexistuje', 404);
      const sloupce = Object.keys(hodnoty);
      db.prepare(`UPDATE polozky SET ${sloupce.map(s => s + '=?').join(',')}, upraveno=datetime('now','localtime') WHERE id=?`)
        .run(...sloupce.map(s => hodnoty[s]), id);
      return polozka(id);
    }
    const sloupce = Object.keys(hodnoty);
    const r = db.prepare(`INSERT INTO polozky(${sloupce.join(',')}) VALUES (${sloupce.map(() => '?').join(',')})`)
      .run(...sloupce.map(s => hodnoty[s]));
    const nid = Number(r.lastInsertRowid);
    db.prepare('UPDATE polozky SET kod=? WHERE id=?').run('LT' + String(nid).padStart(4, '0'), nid);
    const poc = cislo(vstup.pocatecni_stav, 'Počáteční stav');
    if (poc) zapisPohyb(nid, { typ: 'prijem', mnozstvi: poc, poznamka: 'Počáteční stav' }, 'pc', false);
    return polozka(nid);
  });
}

// typ: prijem (+mnozstvi), vydej (-mnozstvi), vazeni (hruba − tara × pocet_obalu = nový stav), oprava (nový stav)
function zapisPohyb(id, v, zdroj = 'pc', vlastniTransakce = true) {
  const proved = () => {
    const p = polozka(id); if (!p) throw new Chyba('Položka neexistuje', 404);
    let novy, hruba = null, pocet = null;
    const typ = v.typ;
    if (typ === 'prijem' || typ === 'vydej') {
      const m = cislo(v.mnozstvi, 'Množství', { povinne: true });
      if (!m) throw new Chyba('Množství musí být větší než nula');
      novy = typ === 'prijem' ? p.stav + m : p.stav - m;
      if (novy < -1e-9) throw new Chyba(`Na skladě je jen ${fmt(p.stav)} ${p.jednotka}`);
    } else if (typ === 'vazeni') {
      hruba = cislo(v.hruba, 'Váha na váze', { povinne: true });
      pocet = Math.round(cislo(v.pocet_obalu, 'Počet obalů') ?? 1);
      novy = hruba - (p.tara || 0) * pocet;
      if (novy < -1e-9) throw new Chyba(`Váha je menší než ${pocet}× prázdný obal (${fmt(p.tara)} kg). Zkontrolujte číslo nebo počet obalů.`);
    } else if (typ === 'oprava') {
      novy = cislo(v.stav, 'Nový stav', { povinne: true });
    } else throw new Chyba('Neznámý pohyb');
    novy = Math.max(0, Math.round(novy * 1000) / 1000);
    const zmena = Math.round((novy - p.stav) * 1000) / 1000;
    const zak = v.zakazka_id ? Number(v.zakazka_id) : null;
    if (zak && !db.prepare('SELECT 1 FROM zakazky WHERE id=?').get(zak)) throw new Chyba('Zakázka neexistuje');
    db.prepare('INSERT INTO pohyby(polozka_id, typ, zmena, stav_po, hruba, pocet_obalu, poznamka, zdroj, zakazka_id) VALUES (?,?,?,?,?,?,?,?,?)')
      .run(id, typ, zmena, novy, hruba, pocet, text(v.poznamka), zdroj, zak);
    db.prepare("UPDATE polozky SET stav=?, upraveno=datetime('now','localtime') WHERE id=?").run(novy, id);
    return { polozka: polozka(id), zmena };
  };
  return vlastniTransakce ? transakce(db, proved) : proved();
}
const fmt = (n) => (Math.round((n || 0) * 1000) / 1000).toLocaleString('cs-CZ');

// ---------- zálohy ----------
function slozkaZaloh() { return nast('zaloha_slozka') || path.join(DATA, 'zalohy'); }
function seznamZaloh() {
  const s = slozkaZaloh();
  if (!fs.existsSync(s)) return [];
  return fs.readdirSync(s).filter(f => /^lakujto-crm-\d{4}-\d{2}-\d{2}.*\.db$/.test(f))
    .map(f => { const st = fs.statSync(path.join(s, f)); return { soubor: f, velikost: st.size, cas: st.mtime.toISOString() }; })
    .sort((a, b) => b.cas.localeCompare(a.cas));
}
function zalohuj(duvod = 'auto') {
  const s = slozkaZaloh();
  fs.mkdirSync(s, { recursive: true });
  const d = new Date(); const den = d.toISOString().slice(0, 10);
  const nazev = duvod === 'auto' ? `lakujto-crm-${den}.db`
    : `lakujto-crm-${den}-${String(d.getHours()).padStart(2, '0')}${String(d.getMinutes()).padStart(2, '0')}-${duvod}.db`;
  const cil = path.join(s, nazev);
  if (fs.existsSync(cil)) fs.rmSync(cil);
  db.exec(`VACUUM INTO '${cil.replace(/'/g, "''")}'`);
  const drz = Math.max(5, Number(nast('zaloha_pocet')) || 30);
  for (const z of seznamZaloh().slice(drz)) fs.rmSync(path.join(s, z.soubor));
  db.prepare("INSERT OR REPLACE INTO nastaveni(klic,hodnota) VALUES ('zaloha_posledni', ?)").run(new Date().toISOString());
  return { soubor: nazev, slozka: s };
}
function zalohujKdyzJeCas() {
  try {
    const posl = nast('zaloha_posledni');
    if (!posl || Date.now() - Date.parse(posl) > 20 * 3600e3) zalohuj('auto');
  } catch (e) { console.error('Záloha selhala:', e.message); stavZalohy.chyba = e.message; return; }
  stavZalohy.chyba = null;
}
const stavZalohy = { chyba: null };
function obnov(soubor) {
  const zdroj = path.join(slozkaZaloh(), path.basename(soubor));
  if (!fs.existsSync(zdroj)) throw new Chyba('Záloha nenalezena', 404);
  const test = new (db.constructor)(zdroj, { readOnly: true });
  try { test.prepare('SELECT count(*) n FROM polozky').get(); } finally { test.close(); }
  zalohuj('pred-obnovou');
  db.close();
  for (const p of ['', '-wal', '-shm']) if (fs.existsSync(DB_SOUBOR + p)) fs.rmSync(DB_SOUBOR + p);
  fs.copyFileSync(zdroj, DB_SOUBOR);
  db = otevri(DB_SOUBOR);
}

// ---------- HTTP ----------
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon' };
function posli(res, kod, data, typ = 'application/json; charset=utf-8') {
  const telo = typeof data === 'string' || Buffer.isBuffer(data) ? data : JSON.stringify(data);
  res.writeHead(kod, { 'Content-Type': typ, 'Cache-Control': 'no-store' });
  res.end(telo);
}
async function telo(req) {
  let s = ''; for await (const c of req) { s += c; if (s.length > 1e6) throw new Chyba('Příliš velký požadavek'); }
  if (!s) return {};
  try { return JSON.parse(s); } catch { throw new Chyba('Neplatná data'); }
}
function staticky(res, soubor) {
  const cesta = path.join(KOREN, 'public', soubor);
  if (!cesta.startsWith(path.join(KOREN, 'public')) || !fs.existsSync(cesta)) return posli(res, 404, 'Nenalezeno', 'text/plain; charset=utf-8');
  posli(res, 200, fs.readFileSync(cesta), MIME[path.extname(cesta)] || 'application/octet-stream');
}

const ROUTY = [];
const r = (metoda, vzor, fn) => ROUTY.push({ metoda, re: new RegExp('^' + vzor.replace(/:(\w+)/g, '(?<$1>[^/]+)') + '$'), fn });

r('GET', '/api/info', () => ({
  verze: VERZE, data: DB_SOUBOR, telefon: adresaProTelefon(), adresy: adresyIP(), port: PORT,
  zaloha: { slozka: slozkaZaloh(), posledni: nast('zaloha_posledni'), chyba: stavZalohy.chyba, pocet: seznamZaloh().length },
}));
r('GET', '/api/prehled', () => ({
  dochazi: db.prepare(POLOZKA_SQL + ' WHERE p.aktivni=1 AND p.min_zasoba>0 AND p.stav<=p.min_zasoba ORDER BY p.stav/p.min_zasoba, p.nazev').all(),
  pocty: db.prepare(`SELECT k.id, k.nazev, count(p.id) n, coalesce(sum(p.stav*coalesce(p.cena,0)),0) hodnota
    FROM kategorie k LEFT JOIN polozky p ON p.kategorie_id=k.id AND p.aktivni=1 WHERE k.aktivni=1 GROUP BY k.id ORDER BY k.poradi, k.nazev`).all(),
  pocty_dalsi: db.prepare(`SELECT (SELECT count(*) FROM dodavatele WHERE aktivni=1) dodavatelu,
    (SELECT count(*) FROM zakaznici WHERE aktivni=1) zakazniku, (SELECT count(*) FROM zamestnanci WHERE aktivni=1) lidi`).get(),
  posledni: db.prepare('SELECT h.*, p.nazev, p.kod, p.jednotka FROM pohyby h JOIN polozky p ON p.id=h.polozka_id ORDER BY h.id DESC LIMIT 12').all(),
}));

r('GET', '/api/dodavatele', () => db.prepare(`SELECT d.*, (SELECT count(*) FROM polozky p WHERE p.dodavatel_id=d.id AND p.aktivni=1) polozek
  FROM dodavatele d WHERE d.aktivni=1 ORDER BY d.nazev`).all());
const ulozDod = (v, id) => {
  const nazev = text(v.nazev); if (!nazev) throw new Chyba('Vyplňte název dodavatele');
  const email = text(v.email); if (email && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) throw new Chyba('E-mail nevypadá správně');
  const h = [nazev, text(v.kontakt_osoba), email, text(v.telefon), text(v.web), text(v.ic), text(v.poznamka)];
  if (id) { db.prepare('UPDATE dodavatele SET nazev=?,kontakt_osoba=?,email=?,telefon=?,web=?,ic=?,poznamka=? WHERE id=?').run(...h, id); return db.prepare('SELECT * FROM dodavatele WHERE id=?').get(id); }
  const rr = db.prepare('INSERT INTO dodavatele(nazev,kontakt_osoba,email,telefon,web,ic,poznamka) VALUES (?,?,?,?,?,?,?)').run(...h);
  return db.prepare('SELECT * FROM dodavatele WHERE id=?').get(Number(rr.lastInsertRowid));
};
r('POST', '/api/dodavatele', async (q) => ulozDod(await telo(q)));
r('PUT', '/api/dodavatele/:id', async (q, p) => ulozDod(await telo(q), Number(p.id)));
// Mazání: když na záznam nic nenavazuje, smaže se úplně. Když je použitý na dokladech nebo v historii,
// jen se vyřadí (zmizí ze seznamů, staré zakázky, faktury a objednávky zůstanou celé).
const pocet = (sql, ...a) => db.prepare(sql).get(...a).n;
function smazNeboVyrad(tab, id, pouziti, nazev) {
  const r = db.prepare(`SELECT * FROM ${tab} WHERE id=?`).get(id); if (!r) throw new Chyba('Záznam nenalezen', 404);
  const duvody = pouziti.filter(([n]) => n > 0).map(([n, t]) => t(n));
  if (duvody.length) {
    db.prepare(`UPDATE ${tab} SET aktivni=0 WHERE id=?`).run(id);
    return { ok: true, jak: 'vyrazeno', zprava: `${nazev(r)}: vyřazeno ze seznamů. Úplně smazat nejde, protože ${duvody.join(' a ')} – ty doklady zůstanou beze změny.` };
  }
  return { ok: true, jak: 'smazano', zprava: `${nazev(r)} – smazáno.` };
}
r('DELETE', '/api/dodavatele/:id', (q, p) => {
  const id = Number(p.id);
  const n = pocet('SELECT count(*) n FROM polozky WHERE dodavatel_id=? AND aktivni=1', id);
  if (n) throw new Chyba(`Dodavatel má ${n} položek na skladě. Nejdřív je smažte nebo přeřaďte jinému dodavateli.`);
  const v = smazNeboVyrad('dodavatele', id, [[pocet('SELECT count(*) n FROM objednavky WHERE dodavatel_id=?', id), (n) => `má ${n} objednávek`],
    [pocet('SELECT count(*) n FROM polozky WHERE dodavatel_id=?', id), (n) => `je u ${n} vyřazených položek skladu`]], (r) => `Dodavatel ${r.nazev}`);
  if (v.jak === 'smazano') transakce(db, () => { db.prepare('DELETE FROM dodavatele WHERE id=?').run(id); db.prepare("DELETE FROM vzor WHERE tabulka='dodavatele' AND radek=?").run(id); });
  return v;
});

r('GET', '/api/polozky', (q, p, url) => {
  const kat = url.searchParams.get('kategorie'); const dod = url.searchParams.get('dodavatel'); const hledej = url.searchParams.get('q');
  let sql = POLOZKA_SQL + ' WHERE p.aktivni=1'; const arg = [];
  if (kat) { sql += ' AND p.kategorie_id=?'; arg.push(Number(kat)); }
  if (dod) { sql += ' AND p.dodavatel_id=?'; arg.push(Number(dod)); }
  if (hledej) { sql += ' AND (p.nazev LIKE ? OR p.kod LIKE ? OR p.ral LIKE ? OR p.vyrobce LIKE ? OR p.kod_dodavatele LIKE ?)'; arg.push(...Array(5).fill('%' + hledej + '%')); }
  return db.prepare(sql + ' ORDER BY k.poradi, k.nazev, p.nazev').all(...arg);
});
r('POST', '/api/polozky', async (q) => ulozPolozku(await telo(q)));
r('GET', '/api/polozky/:id', (q, p) => polozka(Number(p.id)) || (() => { throw new Chyba('Nenalezeno', 404); })());
r('PUT', '/api/polozky/:id', async (q, p) => ulozPolozku(await telo(q), Number(p.id)));
r('DELETE', '/api/polozky/:id', (q, p) => {
  const id = Number(p.id);
  const v = smazNeboVyrad('polozky', id, [[pocet('SELECT count(*) n FROM pohyby WHERE polozka_id=? AND zakazka_id IS NOT NULL', id), (n) => `byla použita na zakázkách (${n}×)`],
    [pocet('SELECT count(*) n FROM objednavky_polozky WHERE polozka_id=?', id), (n) => `je v objednávkách (${n}×)`]], (r) => `Položka ${r.nazev}`);
  if (v.jak === 'smazano') transakce(db, () => { db.prepare('DELETE FROM pohyby WHERE polozka_id=?').run(id); db.prepare('DELETE FROM polozky WHERE id=?').run(id); db.prepare("DELETE FROM vzor WHERE tabulka='polozky' AND radek=?").run(id); });
  return v;
});
r('GET', '/api/kod/:kod', (q, p) => db.prepare(POLOZKA_SQL + ' WHERE p.kod=? AND p.aktivni=1').get(decodeURIComponent(p.kod).toUpperCase()) || (() => { throw new Chyba('Položka s tímto kódem není', 404); })());
r('GET', '/api/polozky/:id/pohyby', (q, p) => db.prepare('SELECT * FROM pohyby WHERE polozka_id=? ORDER BY id DESC LIMIT 200').all(Number(p.id)));
r('POST', '/api/polozky/:id/pohyb', async (q, p) => { const v = await telo(q); return zapisPohyb(Number(p.id), v, v.zdroj === 'telefon' ? 'telefon' : 'pc'); });

// ---------- objednávky u dodavatelů (fáze 2) ----------
const STAVY_OBJ = { koncept: 'Koncept', odeslano: 'Odesláno', prijato: 'Přijato', zruseno: 'Zrušeno' };
function navrhMnozstvi(x) {
  // doplnit do dvojnásobku minimální zásoby, zaokrouhleno nahoru na celá balení
  const min = x.min_zasoba || 0;
  let m = Math.max(0, 2 * min - x.stav);
  if (x.baleni > 0) m = Math.ceil(m / x.baleni - 1e-9) * x.baleni;
  return Math.round(m * 1000) / 1000;
}
function objednavka(id) {
  const o = db.prepare(`SELECT o.*, d.nazev AS dodavatel, d.email AS dodavatel_email, d.kontakt_osoba AS dodavatel_kontakt,
      d.telefon AS dodavatel_telefon, d.ic AS dodavatel_ic FROM objednavky o JOIN dodavatele d ON d.id=o.dodavatel_id WHERE o.id=?`).get(id);
  if (!o) throw new Chyba('Objednávka nenalezena', 404);
  o.polozky = db.prepare(`SELECT op.*, p.kod, p.nazev, p.ral, p.povrch, p.jednotka, p.kod_dodavatele, p.vyrobce, p.stav AS na_sklade
      FROM objednavky_polozky op JOIN polozky p ON p.id=op.polozka_id WHERE op.objednavka_id=? ORDER BY op.id`).all(id);
  o.celkem = Math.round(o.polozky.reduce((s, x) => s + (x.cena || 0) * x.mnozstvi, 0) * 100) / 100;
  o.stav_nazev = STAVY_OBJ[o.stav];
  return o;
}
function dalsiCisloObj() {
  const rok = new Date().getFullYear();
  const posl = db.prepare("SELECT cislo FROM objednavky WHERE cislo LIKE ? ORDER BY cislo DESC LIMIT 1").get(`OBJ-${rok}-%`);
  const n = posl ? Number(posl.cislo.split('-')[2]) + 1 : 1;
  return `OBJ-${rok}-${String(n).padStart(4, '0')}`;
}
function polozkyObj(dodavatel_id, vstup) {
  if (!Array.isArray(vstup) || !vstup.length) throw new Chyba('Objednávka musí mít aspoň jednu položku');
  const vysl = [], videno = new Set();
  for (const v of vstup) {
    const m = cislo(v.mnozstvi, 'Množství');
    if (!m) continue;
    const p = db.prepare('SELECT * FROM polozky WHERE id=? AND aktivni=1').get(Number(v.polozka_id));
    if (!p) throw new Chyba('Položka neexistuje');
    if (p.dodavatel_id !== dodavatel_id) throw new Chyba(`„${p.nazev}“ není od tohoto dodavatele`);
    if (videno.has(p.id)) throw new Chyba(`„${p.nazev}“ je v objednávce dvakrát`);
    videno.add(p.id);
    vysl.push({ polozka_id: p.id, mnozstvi: m, cena: p.cena });
  }
  if (!vysl.length) throw new Chyba('Vyplňte množství aspoň u jedné položky');
  return vysl;
}
r('GET', '/api/objednavky/navrh', () => {
  const rows = db.prepare(POLOZKA_SQL + ' WHERE p.aktivni=1 AND p.dodavatel_id IS NOT NULL AND p.min_zasoba>0 AND p.stav<=p.min_zasoba ORDER BY d.nazev, p.nazev').all();
  const otevrene = new Set(db.prepare(`SELECT op.polozka_id FROM objednavky_polozky op JOIN objednavky o ON o.id=op.objednavka_id WHERE o.stav IN ('koncept','odeslano')`).all().map(x => x.polozka_id));
  const dle = {};
  for (const x of rows) {
    (dle[x.dodavatel_id] ||= { dodavatel_id: x.dodavatel_id, dodavatel: x.dodavatel, polozky: [] })
      .polozky.push({ ...x, navrh: navrhMnozstvi(x), uz_objednano: otevrene.has(x.id) });
  }
  return Object.values(dle);
});
r('GET', '/api/objednavky', (q, p, url) => {
  const st = url.searchParams.get('stav'); const dod = url.searchParams.get('dodavatel');
  let sql = `SELECT o.*, d.nazev AS dodavatel, (SELECT count(*) FROM objednavky_polozky WHERE objednavka_id=o.id) polozek,
    (SELECT coalesce(sum(coalesce(cena,0)*mnozstvi),0) FROM objednavky_polozky WHERE objednavka_id=o.id) celkem
    FROM objednavky o JOIN dodavatele d ON d.id=o.dodavatel_id WHERE 1=1`; const arg = [];
  if (st && STAVY_OBJ[st]) { sql += ' AND o.stav=?'; arg.push(st); }
  if (dod) { sql += ' AND o.dodavatel_id=?'; arg.push(Number(dod)); }
  return db.prepare(sql + ' ORDER BY o.id DESC LIMIT 300').all(...arg);
});
r('GET', '/api/objednavky/:id', (q, p) => objednavka(Number(p.id)));
r('POST', '/api/objednavky', async (q) => {
  const v = await telo(q);
  const dod = db.prepare('SELECT * FROM dodavatele WHERE id=? AND aktivni=1').get(Number(v.dodavatel_id));
  if (!dod) throw new Chyba('Vyberte dodavatele');
  const pol = polozkyObj(dod.id, v.polozky);
  return transakce(db, () => {
    const vz = jeVzor('dodavatele', dod.id);
    const rr = db.prepare('INSERT INTO objednavky(cislo, dodavatel_id, poznamka) VALUES (?,?,?)').run(vz ? dalsiVzorCislo('objednavky', 'OBJ-VZOR-') : dalsiCisloObj(), dod.id, text(v.poznamka));
    const id = Number(rr.lastInsertRowid); if (vz) oznacVzor('objednavky', id);
    for (const x of pol) db.prepare('INSERT INTO objednavky_polozky(objednavka_id, polozka_id, mnozstvi, cena) VALUES (?,?,?,?)').run(id, x.polozka_id, x.mnozstvi, x.cena);
    return objednavka(id);
  });
});
r('PUT', '/api/objednavky/:id', async (q, p) => {
  const v = await telo(q); const o = objednavka(Number(p.id));
  if (o.stav !== 'koncept') throw new Chyba('Upravit jde jen objednávku, která ještě nebyla odeslaná');
  const pol = polozkyObj(o.dodavatel_id, v.polozky);
  return transakce(db, () => {
    db.prepare('DELETE FROM objednavky_polozky WHERE objednavka_id=?').run(o.id);
    for (const x of pol) db.prepare('INSERT INTO objednavky_polozky(objednavka_id, polozka_id, mnozstvi, cena) VALUES (?,?,?,?)').run(o.id, x.polozka_id, x.mnozstvi, x.cena);
    db.prepare('UPDATE objednavky SET poznamka=? WHERE id=?').run(text(v.poznamka), o.id);
    return objednavka(o.id);
  });
});
r('POST', '/api/objednavky/:id/odeslano', (q, p) => {
  const o = objednavka(Number(p.id));
  if (o.stav !== 'koncept' && o.stav !== 'odeslano') throw new Chyba('Tuto objednávku už nejde odeslat');
  db.prepare("UPDATE objednavky SET stav='odeslano', odeslano=coalesce(odeslano, datetime('now','localtime')) WHERE id=?").run(o.id);
  return objednavka(o.id);
});
r('POST', '/api/objednavky/:id/zrusit', (q, p) => {
  const o = objednavka(Number(p.id));
  if (o.stav === 'prijato') throw new Chyba('Přijatou objednávku nejde zrušit');
  db.prepare("UPDATE objednavky SET stav='zruseno' WHERE id=?").run(o.id);
  return objednavka(o.id);
});
r('POST', '/api/objednavky/:id/prijmout', async (q, p) => {
  const v = await telo(q); const o = objednavka(Number(p.id));
  if (o.stav === 'prijato') throw new Chyba('Objednávka už je přijatá');
  if (o.stav === 'zruseno') throw new Chyba('Objednávka je zrušená');
  const prijato = Object.fromEntries((v.polozky || []).map(x => [Number(x.id), cislo(x.prijato, 'Přijaté množství') ?? 0]));
  return transakce(db, () => {
    for (const x of o.polozky) {
      const m = x.id in prijato ? prijato[x.id] : x.mnozstvi;
      db.prepare('UPDATE objednavky_polozky SET prijato=? WHERE id=?').run(m, x.id);
      if (m > 0) zapisPohyb(x.polozka_id, { typ: 'prijem', mnozstvi: m, poznamka: `Objednávka ${o.cislo}` }, 'pc', false);
    }
    db.prepare("UPDATE objednavky SET stav='prijato', prijato=datetime('now','localtime') WHERE id=?").run(o.id);
    return objednavka(o.id);
  });
});
const fmtM = (n) => (Math.round((n || 0) * 1000) / 1000).toLocaleString('cs-CZ');
function radekObj(x) {
  return [x.kod_dodavatele ? `[${x.kod_dodavatele}]` : '', x.nazev, [x.ral, x.povrch].filter(Boolean).join(' '), x.vyrobce ? `(${x.vyrobce})` : '']
    .filter(Boolean).join(' ') + ` – ${fmtM(x.mnozstvi)} ${x.jednotka}`;
}
function emailObj(id) {
  const o = objednavka(id);
  const predmet = `Objednávka ${o.cislo} – ${nast('firma_nazev')} (LakujTo)`;
  const telo = [nast('objednavka_text'), '', `Objednávka č. ${o.cislo}`, '', ...o.polozky.map((x, i) => `${i + 1}. ${radekObj(x)}`),
    ...(o.poznamka ? ['', 'Poznámka: ' + o.poznamka] : []), '',
    `Fakturační údaje: ${nast('firma_nazev')}, ${nast('firma_adresa')}, IČ ${nast('firma_ic')}, DIČ ${nast('firma_dic')}`,
    `Dodací adresa: ${nast('provozovna')}`, `Kontakt: ${nast('firma_telefon')}, ${nast('firma_email')}`,
    ...(nast('objednavka_zaver') ? ['', nast('objednavka_zaver'), nast('firma_nazev') + ' – LakujTo'] : [])].join('\n');
  const mailto = `mailto:${encodeURIComponent(o.dodavatel_email || '')}?subject=${encodeURIComponent(predmet)}&body=${encodeURIComponent(telo)}`;
  return { komu: o.dodavatel_email || '', predmet, telo, mailto, dlouhy: mailto.length > 1900 };
}
r('GET', '/api/objednavky/:id/email', (q, p) => emailObj(Number(p.id)));
r('GET', '/objednavka/:id', (q, p) => {
  const o = objednavka(Number(p.id));
  const kc = (n) => n == null ? '' : Number(n).toLocaleString('cs-CZ', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' Kč';
  const maCeny = o.polozky.some(x => x.cena != null);
  return { __html: `<!doctype html><html lang="cs"><head><meta charset="utf-8"><title>Objednávka ${h(o.cislo)}</title><style>
  @page{size:A4;margin:16mm}body{font-family:Arial,Helvetica,sans-serif;font-size:10.5pt;color:#111;margin:0}
  .hl{display:flex;justify-content:space-between;align-items:flex-start;border-bottom:2px solid #111;padding-bottom:4mm;margin-bottom:6mm}
  .hl img{width:26mm;height:26mm}h1{font-size:18pt;margin:0}.mut{color:#555}
  .strany{display:grid;grid-template-columns:1fr 1fr;gap:8mm;margin-bottom:6mm}.strany div{border:1px solid #bbb;border-radius:2mm;padding:3mm 4mm}
  .strany b{display:block;font-size:9pt;color:#555;text-transform:uppercase;letter-spacing:.3px;margin-bottom:1mm}
  table{width:100%;border-collapse:collapse}th,td{border-bottom:1px solid #ccc;padding:2mm;text-align:left;vertical-align:top}th{font-size:9pt;color:#555;border-bottom:1.5px solid #111}
  td.c,th.c{text-align:right;white-space:nowrap}.text{white-space:pre-line;margin:6mm 0}.pata{margin-top:12mm;font-size:9pt;color:#555}
  .tl{font:15px system-ui,sans-serif;padding:10px;background:#f3f3f7}.tl button{font:inherit;padding:8px 16px}@media print{.tl{display:none}}
  </style></head><body><div class="tl"><button onclick="print()">Tisknout / uložit jako PDF</button> V okně tisku zvolte „Uložit jako PDF“, pokud chcete soubor přiložit k e-mailu.</div>
  <div style="padding:0 2mm">
  <div class="hl"><div><h1>Objednávka</h1><div style="font-size:13pt;font-weight:bold">${h(o.cislo)}</div><div class="mut">Datum: ${new Date((o.odeslano || o.vytvoreno).replace(' ', 'T')).toLocaleDateString('cs-CZ')}</div></div><img src="/static/logo.png" alt=""></div>
  <div class="strany"><div><b>Odběratel</b>${h(nast('firma_nazev'))}<br>${h(nast('firma_adresa'))}<br>IČ ${h(nast('firma_ic'))} · DIČ ${h(nast('firma_dic'))}<br><br><b>Dodací adresa</b>${h(nast('provozovna'))}<br>${h(nast('firma_telefon'))} · ${h(nast('firma_email'))}</div>
  <div><b>Dodavatel</b>${h(o.dodavatel)}${o.dodavatel_ic ? '<br>IČ ' + h(o.dodavatel_ic) : ''}${o.dodavatel_kontakt ? '<br>' + h(o.dodavatel_kontakt) : ''}${o.dodavatel_email ? '<br>' + h(o.dodavatel_email) : ''}${o.dodavatel_telefon ? '<br>' + h(o.dodavatel_telefon) : ''}</div></div>
  <div class="text">${h(nast('objednavka_text'))}</div>
  <table><tr><th>#</th><th>Kód dodavatele</th><th>Zboží</th><th class="c">Množství</th>${maCeny ? '<th class="c">Cena/j. bez DPH</th><th class="c">Celkem bez DPH</th>' : ''}</tr>
  ${o.polozky.map((x, i) => `<tr><td>${i + 1}</td><td>${h(x.kod_dodavatele || '')}</td><td><b>${h(x.nazev)}</b>${x.ral || x.povrch ? '<br>' + h([x.ral, x.povrch].filter(Boolean).join(' ')) : ''}${x.vyrobce ? '<br><span class="mut">' + h(x.vyrobce) + '</span>' : ''}</td><td class="c">${fmtM(x.mnozstvi)} ${h(x.jednotka)}</td>${maCeny ? `<td class="c">${kc(x.cena)}</td><td class="c">${x.cena != null ? kc(x.cena * x.mnozstvi) : ''}</td>` : ''}</tr>`).join('')}
  ${maCeny ? `<tr><td colspan="5" class="c"><b>Orientačně celkem bez DPH</b></td><td class="c"><b>${kc(o.celkem)}</b></td></tr>` : ''}</table>
  ${o.poznamka ? `<p><b>Poznámka:</b> ${h(o.poznamka)}</p>` : ''}
  ${nast('objednavka_zaver') ? `<p style="margin-top:8mm">${h(nast('objednavka_zaver'))}<br>${h(nast('firma_nazev'))} – LakujTo</p>` : ''}
  <div class="pata">Ceny jsou orientační podle naší evidence, platí ceny dodavatele. Vystavil: ${h(nast('firma_nazev'))}, provozovna LakujTo.</div>
  </div></body></html>` };
});

// ---------- Thunderbird + PDF (objednávka jako příloha) ----------
const PF = process.env.ProgramFiles || 'C:\\Program Files';
const PF86 = process.env['ProgramFiles(x86)'] || 'C:\\Program Files (x86)';
const LAD = process.env.LOCALAPPDATA || '';
function najdi(seznam) { return seznam.filter(Boolean).find(p => { try { return fs.existsSync(p); } catch { return false; } }) || null; }
const prohlizec = () => najdi([process.env.LAKUJTO_PROHLIZEC,
  ...(process.platform === 'win32' ? [
    path.join(PF86, 'Microsoft', 'Edge', 'Application', 'msedge.exe'), path.join(PF, 'Microsoft', 'Edge', 'Application', 'msedge.exe'),
    path.join(PF, 'Google', 'Chrome', 'Application', 'chrome.exe'), path.join(PF86, 'Google', 'Chrome', 'Application', 'chrome.exe'),
    LAD && path.join(LAD, 'Google', 'Chrome', 'Application', 'chrome.exe')]
  : ['/Applications/Google Chrome.app/Contents/MacOS/Google Chrome', '/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge'])]);
const thunderbird = () => najdi([process.env.LAKUJTO_THUNDERBIRD,
  ...(process.platform === 'win32' ? [path.join(PF, 'Mozilla Thunderbird', 'thunderbird.exe'), path.join(PF86, 'Mozilla Thunderbird', 'thunderbird.exe')]
  : ['/Applications/Thunderbird.app/Contents/MacOS/thunderbird'])]);
function jenTentoPocitac(q) {
  const z = q.socket.remoteAddress || '';
  if (!['127.0.0.1', '::1', '::ffff:127.0.0.1'].includes(z)) throw new Chyba('Tohle jde jen z počítače, na kterém program běží', 403);
}
function vyrobPdf(url, cil) {
  const p = prohlizec(); if (!p) throw new Chyba('Na počítači nenacházím Edge ani Chrome, PDF nejde vyrobit');
  fs.mkdirSync(path.dirname(cil), { recursive: true });
  if (fs.existsSync(cil)) fs.rmSync(cil);
  const profil = path.join(DATA, 'prohlizec-pdf');
  return new Promise((ok, chyba) => {
    const c = spawn(p, ['--headless', '--disable-gpu', '--no-first-run', '--no-default-browser-check', `--user-data-dir=${profil}`,
      '--no-pdf-header-footer', `--print-to-pdf=${cil}`, url], { stdio: 'ignore', windowsHide: true });
    const t = setTimeout(() => { c.kill(); chyba(new Chyba('Výroba PDF trvala příliš dlouho')); }, 45000);
    c.on('error', (e) => { clearTimeout(t); chyba(new Chyba('PDF nejde vyrobit: ' + e.message)); });
    c.on('exit', () => { clearTimeout(t); try { if (fs.statSync(cil).size > 500) return ok(cil); } catch {} chyba(new Chyba('PDF se nevytvořilo')); });
  });
}
const tbHodnota = (v) => String(v ?? '').replace(/'/g, '’');
r('GET', '/api/schopnosti', () => ({ thunderbird: !!thunderbird(), pdf: !!prohlizec(), email_odesilatel: nast('firma_email') }));
r('POST', '/api/objednavky/:id/pdf', async (q, p) => {
  jenTentoPocitac(q);
  const o = objednavka(Number(p.id));
  const pdf = await vyrobPdf(`http://127.0.0.1:${PORT}/objednavka/${o.id}`, path.join(DATA, 'objednavky', `${o.cislo}.pdf`));
  return { pdf };
});
async function doThunderbirdu({ komu, predmet, telo, url, slozka, nazev }) {
  const tb = thunderbird(); if (!tb) throw new Chyba('Thunderbird na tomto počítači nenacházím');
  const dir = path.join(DATA, slozka);
  let pdf = null, varovani = null;
  try { pdf = await vyrobPdf(url, path.join(dir, `${nazev}.pdf`)); }
  catch (err) { varovani = 'E-mail se otevře bez PDF přílohy: ' + err.message; }
  fs.mkdirSync(dir, { recursive: true });
  const txt = path.join(dir, `${nazev}.txt`);
  fs.writeFileSync(txt, telo, 'utf8');
  const casti = [`to='${tbHodnota(komu)}'`, `subject='${tbHodnota(predmet)}'`, `message='${txt}'`, 'format=2'];
  if (pdf) casti.push(`attachment='${pathToFileURL(pdf).href}'`);
  const od = nast('firma_email'); if (od) casti.push(`from='${tbHodnota(od)}'`);
  await new Promise((ok, chyba) => {
    const c = spawn(tb, ['-compose', casti.join(',')], { detached: true, stdio: 'ignore', windowsHide: false });
    c.on('error', (err) => chyba(new Chyba('Thunderbird nejde spustit: ' + err.message)));
    c.on('spawn', () => { c.unref(); ok(); });
  });
  return { ok: true, pdf, varovani };
}
r('POST', '/api/objednavky/:id/thunderbird', async (q, p) => {
  jenTentoPocitac(q);
  const o = objednavka(Number(p.id)); const e = emailObj(o.id);
  return doThunderbirdu({ komu: e.komu, predmet: e.predmet, telo: e.telo, url: `http://127.0.0.1:${PORT}/objednavka/${o.id}`, slozka: 'objednavky', nazev: o.cislo });
});

// ---------- ceník služeb ----------
r('GET', '/api/sluzby', () => db.prepare('SELECT * FROM sluzby WHERE aktivni=1 ORDER BY poradi, nazev').all());
const ulozSluzbu = (v, id) => {
  const nazev = text(v.nazev); if (!nazev) throw new Chyba('Vyplňte název služby');
  const h = [nazev, text(v.jednotka) || 'ks', cislo(v.cena, 'Cena', { povinne: true })];
  if (id) { db.prepare('UPDATE sluzby SET nazev=?, jednotka=?, cena=? WHERE id=?').run(...h, id); return db.prepare('SELECT * FROM sluzby WHERE id=?').get(id); }
  const por = db.prepare('SELECT coalesce(max(poradi),0)+1 n FROM sluzby').get().n;
  const rr = db.prepare('INSERT INTO sluzby(nazev, jednotka, cena, poradi) VALUES (?,?,?,?)').run(...h, por);
  return db.prepare('SELECT * FROM sluzby WHERE id=?').get(Number(rr.lastInsertRowid));
};
r('POST', '/api/sluzby', async (q) => ulozSluzbu(await telo(q)));
r('PUT', '/api/sluzby/:id', async (q, p) => ulozSluzbu(await telo(q), Number(p.id)));
r('DELETE', '/api/sluzby/:id', (q, p) => { db.prepare('UPDATE sluzby SET aktivni=0 WHERE id=?').run(Number(p.id)); return { ok: true }; });

// ---------- zakázky (fáze 3) ----------
const STAVY_ZAK = { prijato: 'Přijato', v_praci: 'V práci', hotovo: 'Hotovo – čeká na vyzvednutí', predano: 'Předáno', zruseno: 'Zrušeno' };
const VADY = { koroze: 'koroze / rezivění', odreniny: 'odřeniny, škrábance, údery o obrubník', praskliny: 'praskliny, deformace, ohnutí',
  opravy: 'předchozí opravy, tmel, sváry', odlupuje: 'původní lak / povrchová úprava odlupuje', znecisteni: 'znečištění olejem, mastnotou, chemií',
  stary: 'starý materiál', chybi: 'chybí díly' };
const dph = () => (Number(nast('dph')) || 21) / 100;
const zaokr = (n) => Math.round(n * 100) / 100;
function zakazka(id) {
  const z = db.prepare(`SELECT z.*, k.nazev AS zakaznik, k.druh AS zakaznik_druh, k.ic AS zakaznik_ic, k.dic AS zakaznik_dic, k.ulice, k.psc, k.mesto,
      k.telefon AS zakaznik_telefon, k.email AS zakaznik_email, k.kontakt_osoba FROM zakazky z JOIN zakaznici k ON k.id=z.zakaznik_id WHERE z.id=?`).get(id);
  if (!z) throw new Chyba('Zakázka nenalezena', 404);
  z.vady = JSON.parse(z.vady || '[]');
  z.polozky = db.prepare('SELECT * FROM zakazky_polozky WHERE zakazka_id=? ORDER BY poradi, id').all(id);
  z.spotreba = db.prepare(`SELECT h.id, h.cas, -h.zmena AS mnozstvi, p.id AS polozka_id, p.kod, p.nazev, p.ral, p.jednotka, p.cena,
      round(-h.zmena*coalesce(p.cena,0),2) AS naklad FROM pohyby h JOIN polozky p ON p.id=h.polozka_id WHERE h.zakazka_id=? ORDER BY h.id`).all(id);
  z.bez_dph = zaokr(z.polozky.reduce((s, x) => s + x.ks * x.cena, 0));
  z.s_dph = zaokr(z.bez_dph * (1 + dph()));
  z.material = zaokr(z.spotreba.reduce((s, x) => s + x.naklad, 0));
  z.prace = zaokr(db.prepare('SELECT coalesce(sum(hodin*sazba),0) s FROM hodiny WHERE zakazka_id=?').get(id).s);
  z.hodin = zaokr(db.prepare('SELECT coalesce(sum(hodin),0) s FROM hodiny WHERE zakazka_id=?').get(id).s);
  z.fakturovano = zaokr(db.prepare("SELECT coalesce(sum(zaklad),0) s FROM penize WHERE (faktura_id IN (SELECT id FROM faktury WHERE zakazka_id=?)) OR (zakazka_id=? AND kategorie='zaloha')").get(id, id).s);
  z.stav_nazev = STAVY_ZAK[z.stav];
  z.ceka_dni = z.stav === 'hotovo' && z.hotovo_dne ? Math.floor((Date.now() - Date.parse(z.hotovo_dne.replace(' ', 'T'))) / 864e5) : null;
  return z;
}
function dalsiCisloZak() {
  const rok = new Date().getFullYear();
  const posl = db.prepare('SELECT cislo FROM zakazky WHERE cislo LIKE ? ORDER BY cislo DESC LIMIT 1').get(`Z-${rok}-%`);
  return `Z-${rok}-${String(posl ? Number(posl.cislo.split('-')[2]) + 1 : 1).padStart(4, '0')}`;
}
function hodnotyZak(v) {
  const vady = Array.isArray(v.vady) ? v.vady.filter(x => VADY[x]) : [];
  const termin = text(v.termin); if (termin && !/^\d{4}-\d{2}-\d{2}$/.test(termin)) throw new Chyba('Termín zadejte jako datum');
  return { prevzal: text(v.prevzal), termin, informovat: ['sms', 'telefon', 'email'].includes(v.informovat) ? v.informovat : null,
    prislusenstvi: text(v.prislusenstvi), zakryt: text(v.zakryt), vady: JSON.stringify(vady), vady_poznamka: text(v.vady_poznamka),
    stari_let: text(v.stari_let), chybi_dily: text(v.chybi_dily), fotek: v.fotek === '' || v.fotek == null ? null : Math.round(cislo(v.fotek, 'Počet fotek')),
    souhlas_foto: v.souhlas_foto === true || v.souhlas_foto === 1 || v.souhlas_foto === '1' ? 1 : 0,
    zaloha: cislo(v.zaloha, 'Záloha') ?? 0, poznamka: text(v.poznamka) };
}
function polozkyZak(vstup) {
  const out = (Array.isArray(vstup) ? vstup : []).filter(x => text(x.co) || text(x.prace)).map((x, i) => {
    if (!text(x.co)) throw new Chyba(`Řádek ${i + 1}: vyplňte, co zákazník přinesl`);
    const sl = x.sluzba_id ? db.prepare('SELECT id FROM sluzby WHERE id=?').get(Number(x.sluzba_id)) : null;
    return { co: text(x.co), ks: cislo(x.ks, 'Počet') ?? 1, material: text(x.material), prace: text(x.prace), barva: text(x.barva),
      sluzba_id: sl ? sl.id : null, cena: cislo(x.cena, 'Cena') ?? 0, poradi: i };
  });
  if (!out.length) throw new Chyba('Zakázka musí mít aspoň jeden řádek – co zákazník přinesl');
  return out;
}
function ulozPolozkyZak(id, pol) {
  db.prepare('DELETE FROM zakazky_polozky WHERE zakazka_id=?').run(id);
  for (const x of pol) db.prepare('INSERT INTO zakazky_polozky(zakazka_id, co, ks, material, prace, barva, sluzba_id, cena, poradi) VALUES (?,?,?,?,?,?,?,?,?)')
    .run(id, x.co, x.ks, x.material, x.prace, x.barva, x.sluzba_id, x.cena, x.poradi);
}
r('GET', '/api/zakazky', (q, p, url) => {
  const st = url.searchParams.get('stav'), hl = url.searchParams.get('q'), zk = url.searchParams.get('zakaznik');
  let sql = `SELECT z.id FROM zakazky z JOIN zakaznici k ON k.id=z.zakaznik_id WHERE 1=1`; const arg = [];
  if (st === 'otevrene') sql += " AND z.stav IN ('prijato','v_praci','hotovo')";
  else if (st && STAVY_ZAK[st]) { sql += ' AND z.stav=?'; arg.push(st); }
  if (zk) { sql += ' AND z.zakaznik_id=?'; arg.push(Number(zk)); }
  if (hl) { const l = '%' + hl + '%'; sql += ' AND (z.cislo LIKE ? OR k.nazev LIKE ? OR k.telefon LIKE ? OR EXISTS (SELECT 1 FROM zakazky_polozky x WHERE x.zakazka_id=z.id AND (x.co LIKE ? OR x.barva LIKE ?)))'; arg.push(l, l, l, l, l); }
  return db.prepare(sql + ' ORDER BY z.id DESC LIMIT 300').all(...arg).map(x => { const z = zakazka(x.id); delete z.spotreba; return z; });
});
r('GET', '/api/zakazky/:id', (q, p) => zakazka(Number(p.id)));
r('POST', '/api/zakazky', async (q) => {
  const v = await telo(q);
  const h = hodnotyZak(v); const pol = polozkyZak(v.polozky);
  return transakce(db, () => {
    let zid = Number(v.zakaznik_id) || null;
    if (!zid && v.novy_zakaznik) zid = ulozZak(v.novy_zakaznik).id;
    if (!zid || !db.prepare('SELECT 1 FROM zakaznici WHERE id=? AND aktivni=1').get(zid)) throw new Chyba('Vyberte zákazníka nebo vyplňte nového');
    const sl = Object.keys(h); const vz = jeVzor('zakaznici', zid);
    const rr = db.prepare(`INSERT INTO zakazky(cislo, zakaznik_id, ${sl.join(',')}) VALUES (?,?,${sl.map(() => '?').join(',')})`).run(vz ? dalsiVzorCislo('zakazky', 'Z-VZOR-') : dalsiCisloZak(), zid, ...sl.map(k => h[k]));
    const id = Number(rr.lastInsertRowid); if (vz) oznacVzor('zakazky', id); ulozPolozkyZak(id, pol);
    syncZaloha(id); return zakazka(id);
  });
});
r('PUT', '/api/zakazky/:id', async (q, p) => {
  const v0 = await telo(q); const z = zakazka(Number(p.id));
  if (z.stav === 'zruseno') throw new Chyba('Zrušenou zakázku nejde upravit');
  // co v požadavku chybí, zůstává jak bylo
  const v = { ...z, polozky: z.polozky, ...Object.fromEntries(Object.entries(v0).filter(([, x]) => x !== undefined)) };
  const h = hodnotyZak(v); const pol = polozkyZak(v.polozky);
  return transakce(db, () => {
    const zid = Number(v.zakaznik_id) || z.zakaznik_id;
    if (!db.prepare('SELECT 1 FROM zakaznici WHERE id=? AND aktivni=1').get(zid)) throw new Chyba('Zákazník neexistuje');
    const sl = Object.keys(h);
    db.prepare(`UPDATE zakazky SET zakaznik_id=?, ${sl.map(k => k + '=?').join(',')} WHERE id=?`).run(zid, ...sl.map(k => h[k]), z.id);
    ulozPolozkyZak(z.id, pol);
    syncZaloha(z.id); return zakazka(z.id);
  });
});
const PRECHODY = { prijato: ['v_praci', 'hotovo', 'zruseno'], v_praci: ['prijato', 'hotovo', 'zruseno'], hotovo: ['v_praci', 'predano', 'zruseno'], predano: ['hotovo'], zruseno: ['prijato'] };
r('POST', '/api/zakazky/:id/stav', async (q, p) => {
  const v = await telo(q); const z = zakazka(Number(p.id)); const novy = v.stav;
  if (!STAVY_ZAK[novy]) throw new Chyba('Neznámý stav');
  if (!PRECHODY[z.stav].includes(novy)) throw new Chyba(`Ze stavu „${STAVY_ZAK[z.stav]}“ nejde přejít na „${STAVY_ZAK[novy]}“`);
  db.prepare(`UPDATE zakazky SET stav=?,
      hotovo_dne = CASE WHEN ?='hotovo' THEN coalesce(hotovo_dne, datetime('now','localtime')) WHEN ? IN ('prijato','v_praci') THEN NULL ELSE hotovo_dne END,
      predano_dne = CASE WHEN ?='predano' THEN datetime('now','localtime') WHEN ?='hotovo' THEN NULL ELSE predano_dne END,
      vyhrada = CASE WHEN ?='predano' THEN ? ELSE vyhrada END WHERE id=?`)
    .run(novy, novy, novy, novy, novy, novy, text(v.vyhrada), z.id);
  syncZaloha(z.id); return zakazka(z.id);
});
r('POST', '/api/zakazky/:id/spotreba', async (q, p) => {
  const v = await telo(q); const z = zakazka(Number(p.id));
  if (z.stav === 'zruseno') throw new Chyba('Na zrušenou zakázku nejde odepisovat');
  zapisPohyb(Number(v.polozka_id), { typ: 'vydej', mnozstvi: v.mnozstvi, poznamka: `Zakázka ${z.cislo}`, zakazka_id: z.id }, v.zdroj === 'telefon' ? 'telefon' : 'pc');
  syncZaloha(z.id); return zakazka(z.id);
});
r('GET', '/api/vady', () => VADY);
r('GET', '/zakazka/:id', (q, p) => {
  const z = zakazka(Number(p.id));
  const kc = (n) => Number(n || 0).toLocaleString('cs-CZ', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' Kč';
  const d = (s) => s ? new Date(s.replace(' ', 'T')).toLocaleDateString('cs-CZ') : '';
  const box = (b) => b ? '☒' : '☐';
  const skl = nast('skladne_kc').trim();
  const uj = nast('zakazka_ujednani').split(/\n\s*\n/).map(x => x.trim()).filter(Boolean).map(x => {
    // bez vyplněného skladného se věta o skladném netiskne (Jiří 6. 11.: „Zatím bez skladného")
    const t = skl ? x.replaceAll('{skladne}', skl)
      : x.replace(/\s*[^.]*\{skladne\}[^.]*\./g, '').replace(/,\s*skladné a /g, ' a ').replace(/\s+skladné,/g, '');
    const i = t.indexOf('. ');
    return i > 0 && i < 50 ? `<p><b>${h(t.slice(0, i + 1))}</b> ${h(t.slice(i + 2))}</p>` : `<p>${h(t)}</p>`; }).join('');
  const radky = [...z.polozky]; while (radky.length < 4) radky.push(null);
  const adresa = [z.ulice, [z.psc, z.mesto].filter(Boolean).join(' ')].filter(Boolean).join(', ');
  return { __html: `<!doctype html><html lang="cs"><head><meta charset="utf-8"><title>Zakázka ${h(z.cislo)}</title><style>
  @page{size:A4;margin:12mm 13mm}body{font-family:Arial,Helvetica,sans-serif;font-size:9.6pt;color:#111;margin:0;line-height:1.32}
  h1{font-size:15pt;margin:0}h2{font-size:10.5pt;margin:4mm 0 1.5mm;border-bottom:1.5px solid #111;padding-bottom:.6mm}
  .hl{display:flex;justify-content:space-between;align-items:flex-start;gap:6mm}.hl img{width:20mm;height:20mm}
  table{width:100%;border-collapse:collapse}td,th{border:1px solid #777;padding:1.2mm 1.6mm;text-align:left;vertical-align:top}th{font-size:8.3pt;background:#f2f2f2}
  .k{width:34%;background:#fafafa;font-size:8.6pt}.c{text-align:right;white-space:nowrap}.mut{color:#555;font-size:8.6pt}
  .vady{columns:2;column-gap:8mm}.vady div{break-inside:avoid}.uj p{margin:0 0 1.4mm;font-size:8.4pt;text-align:justify}
  .podpis td{height:11mm}.tl{font:15px system-ui,sans-serif;padding:10px;background:#f3f3f7}.tl button{font:inherit;padding:8px 16px}
  @media print{.tl{display:none}}</style></head><body>
  <div class="tl"><button onclick="print()">Tisknout</button> Vytiskněte 2× – jeden pro zákazníka, jeden zůstává v lakovně.</div>
  <div class="hl"><div><h1>Zakázkový list a předávací protokol</h1>
  <div class="mut">Zhotovitel: ${h(nast('firma_nazev'))}, IČ ${h(nast('firma_ic'))}, ${h(nast('firma_adresa'))} · provozovna ${h(nast('provozovna'))} · ${h(nast('firma_telefon'))} · ${h(nast('firma_email'))}</div></div>
  <img src="/static/logo.png" alt=""></div>
  <table style="margin-top:3mm"><tr><th>Číslo zakázky</th><th>Datum převzetí</th><th>Převzal</th><th>Termín</th></tr>
  <tr><td><b style="font-size:11pt">${h(z.cislo)}</b></td><td>${d(z.prijato_dne)}</td><td>${h(z.prevzal || '')}</td><td>${z.termin ? d(z.termin) : ''}</td></tr></table>
  <h2>1. Zákazník</h2><table>
  <tr><td class="k">Jméno a příjmení / firma</td><td>${h(z.zakaznik)}${z.kontakt_osoba ? ' – ' + h(z.kontakt_osoba) : ''}</td></tr>
  ${z.zakaznik_druh === 'firma' ? `<tr><td class="k">IČ / DIČ</td><td>${h(z.zakaznik_ic || '')} ${z.zakaznik_dic ? '/ ' + h(z.zakaznik_dic) : ''}</td></tr>` : ''}
  <tr><td class="k">Adresa</td><td>${h(adresa)}</td></tr><tr><td class="k">Telefon / e-mail</td><td>${h(z.zakaznik_telefon || '')} ${z.zakaznik_email ? '· ' + h(z.zakaznik_email) : ''}</td></tr>
  <tr><td class="k">Informovat o hotové zakázce</td><td>${box(z.informovat === 'sms')} SMS &nbsp; ${box(z.informovat === 'telefon')} telefon &nbsp; ${box(z.informovat === 'email')} e-mail</td></tr></table>
  <h2>2. Předané věci a požadovaná práce</h2><table>
  <tr><th>#</th><th>Co</th><th>Ks</th><th>Materiál</th><th>Co se má udělat</th><th>Barva RAL / povrch</th><th class="c">Cena bez DPH</th></tr>
  ${radky.map((x, i) => x ? `<tr><td>${i + 1}</td><td>${h(x.co)}</td><td>${fmtM(x.ks)}</td><td>${h(x.material || '')}</td><td>${h(x.prace || '')}</td><td>${h(x.barva || '')}</td><td class="c">${x.cena ? kc(x.ks * x.cena) : ''}</td></tr>` : `<tr><td>${i + 1}</td><td>&nbsp;</td><td></td><td></td><td></td><td></td><td></td></tr>`).join('')}</table>
  <p style="margin:1.5mm 0"><b>Příslušenství předané s věcí:</b> ${h(z.prislusenstvi || '—')}<br><b>Místa, která se nesmí lakovat / zakrýt:</b> ${h(z.zakryt || '—')}</p>
  <h2>3. Stav při převzetí</h2><div class="vady">${Object.entries(VADY).map(([k, t]) => `<div>${box(z.vady.includes(k))} ${h(t)}${k === 'stary' && z.stari_let ? ` (odhad stáří: ${h(z.stari_let)} let)` : ''}${k === 'chybi' && z.chybi_dily ? ` (${h(z.chybi_dily)})` : ''}</div>`).join('')}</div>
  <p style="margin:1.5mm 0"><b>Jiné vady nebo poznámky:</b> ${h(z.vady_poznamka || '—')}<br>Fotodokumentace při převzetí: ${box(z.fotek > 0)} pořízena${z.fotek > 0 ? ` (počet fotek: ${z.fotek})` : ''}</p>
  <h2>4. Cena a termín</h2><table><tr><th>Předběžná cena bez DPH</th><th>Předběžná cena s DPH ${Math.round(dph() * 100)} %</th><th>Záloha zaplacena</th><th>Předpokládaný termín</th></tr>
  <tr><td>${kc(z.bez_dph)}</td><td><b>${kc(z.s_dph)}</b></td><td>${z.zaloha ? kc(z.zaloha) : '—'}</td><td>${z.termin ? d(z.termin) : ''}</td></tr></table>
  <p class="mut" style="margin:1mm 0">Cena je orientační a podle skutečného poškození se může lišit až o 20 %. Když se při práci objeví skrytá vada a cena by měla vzrůst, zhotovitel zákazníkovi nejdřív zavolá a bez jeho souhlasu nad sjednanou cenu nepokračuje.</p>
  ${z.poznamka ? `<p style="margin:1mm 0"><b>Poznámka:</b> ${h(z.poznamka)}</p>` : ''}
  <h2>5. Smluvní ujednání</h2><div class="uj"><p>Zákazník podpisem potvrzuje, že si následující body přečetl, pracovník mu je vysvětlil a souhlasí s nimi.</p>${uj}
  <p>${box(z.souhlas_foto)} Zákazník souhlasí, že fotky hotové práce (bez osobních údajů a SPZ) smíme použít na webu a sociálních sítích. (dobrovolné)</p></div>
  <h2>6. Podpisy</h2><p style="margin:0 0 1mm">Při převzetí zakázky — potvrzuji, že údaje jsou pravdivé, stav věci je zapsán správně a se smluvními ujednáními souhlasím.</p>
  <table class="podpis"><tr><th style="width:22%"></th><th style="width:25%">Datum</th><th>Podpis</th></tr><tr><td>Zákazník</td><td>${d(z.prijato_dne)}</td><td></td></tr><tr><td>Za zhotovitele</td><td>${d(z.prijato_dne)}</td><td></td></tr></table>
  <p style="margin:2mm 0 1mm">Při výdeji zakázky — věci jsem převzal ${box(z.stav === 'predano' && !z.vyhrada)} bez výhrad ${box(!!z.vyhrada)} s výhradou: ${h(z.vyhrada || '……………………………………………')}</p>
  <table class="podpis"><tr><th style="width:22%"></th><th style="width:25%">Datum</th><th>Podpis</th></tr><tr><td>Zákazník</td><td>${d(z.predano_dne)}</td><td></td></tr><tr><td>Za zhotovitele</td><td>${d(z.predano_dne)}</td><td></td></tr></table>
  </body></html>` };
});

// ---------- faktury (fáze 4) — obecné, údaje firmy se zapíšou do faktury při vystavení ----------
const ZPUSOBY = { prevod: 'převodem', hotove: 'hotově', karta: 'kartou' };
const dnes = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };
const plusDni = (iso, n) => { const d = new Date(iso + 'T12:00:00'); d.setDate(d.getDate() + n); return d.toISOString().slice(0, 10); };
const jeDatum = (t) => /^\d{4}-\d{2}-\d{2}$/.test(t || '') && !isNaN(Date.parse(t));
function firmaTed() {
  const iban = nast('firma_iban') || ibanZUctu(nast('firma_ucet')) || '';
  return { nazev: nast('firma_nazev'), ic: nast('firma_ic'), dic: nast('firma_dic'), adresa: nast('firma_adresa'), provozovna: nast('provozovna'),
    email: nast('firma_email'), telefon: nast('firma_telefon'), ucet: nast('firma_ucet'), iban, banka: nast('firma_banka'),
    rejstrik: nast('firma_rejstrik'), vystavil: nast('faktura_vystavil'), text: nast('faktura_text') };
}
function faktura(id) {
  const f = db.prepare('SELECT * FROM faktury WHERE id=?').get(id);
  if (!f) throw new Chyba('Faktura nenalezena', 404);
  f.dodavatel = JSON.parse(f.dodavatel); f.odberatel = JSON.parse(f.odberatel);
  f.polozky = db.prepare('SELECT * FROM faktury_polozky WHERE faktura_id=? ORDER BY poradi, id').all(id);
  f.soucty = soucty(f.polozky, { platce: !!f.platce_dph, zpusob: f.zpusob, zaloha: f.zaloha });
  f.po_splatnosti = f.stav === 'vystavena' && f.splatnost < dnes();
  f.zakazka_cislo = f.zakazka_id ? db.prepare('SELECT cislo FROM zakazky WHERE id=?').get(f.zakazka_id)?.cislo : null;
  f.qr = f.stav !== 'stornovana' && f.zpusob === 'prevod' && f.soucty.k_uhrade > 0 && overIban(f.dodavatel.iban)
    ? spayd({ iban: f.dodavatel.iban, castka: f.soucty.k_uhrade, vs: f.cislo, splatnost: f.splatnost, zprava: `Faktura ${f.cislo} ${f.dodavatel.nazev}` }) : null;
  return f;
}
function dalsiCisloFak(rok) {
  const posl = db.prepare('SELECT cislo FROM faktury WHERE cislo LIKE ? ORDER BY cislo DESC LIMIT 1').get(`${rok}____`);
  return `${rok}${String(posl ? Number(posl.cislo.slice(4)) + 1 : 1).padStart(4, '0')}`;
}
function polozkyFak(vstup, platce) {
  const out = (Array.isArray(vstup) ? vstup : []).filter(x => text(x.popis)).map((x, i) => {
    const sazba = platce ? (cislo(x.sazba, 'Sazba DPH') ?? 21) : 0;
    if (![0, 12, 21].includes(sazba)) throw new Chyba('Sazba DPH může být 21, 12 nebo 0 %');
    const cena = cislo(x.cena, 'Cena', { min: null }) ?? 0;
    return { popis: text(x.popis), mnozstvi: cislo(x.mnozstvi, 'Množství') ?? 1, jednotka: text(x.jednotka), cena, sazba, poradi: i };
  });
  if (!out.length) throw new Chyba('Faktura musí mít aspoň jednu položku');
  return out;
}
function odberatelZ(zid) {
  const k = db.prepare('SELECT * FROM zakaznici WHERE id=? AND aktivni=1').get(zid);
  if (!k) throw new Chyba('Vyberte odběratele (zákazníka)');
  return { nazev: k.nazev, kontakt: k.kontakt_osoba, ulice: k.ulice, psc: k.psc, mesto: k.mesto, ic: k.ic, dic: k.dic, email: k.email, telefon: k.telefon };
}
function hlavickaFak(v) {
  const vystaveno = text(v.vystaveno) || dnes(); if (!jeDatum(vystaveno)) throw new Chyba('Datum vystavení není platné');
  const duzp = text(v.duzp) || vystaveno; if (!jeDatum(duzp)) throw new Chyba('DUZP není platné datum');
  const zpusob = ZPUSOBY[v.zpusob] ? v.zpusob : 'prevod';
  const dni = Math.round(cislo(v.splatnost_dni, 'Splatnost') ?? (Number(nast('faktura_splatnost')) || 14));
  const splatnost = text(v.splatnost) || (zpusob === 'prevod' ? plusDni(vystaveno, dni) : vystaveno);
  if (!jeDatum(splatnost)) throw new Chyba('Splatnost není platné datum');
  if (splatnost < vystaveno) throw new Chyba('Splatnost nemůže být dřív než vystavení');
  return { vystaveno, duzp, splatnost, zpusob, zaloha: cislo(v.zaloha, 'Záloha') ?? 0, poznamka: text(v.poznamka) };
}
r('GET', '/api/faktury', (q, p, url) => {
  const st = url.searchParams.get('stav'), hl = url.searchParams.get('q');
  let sql = 'SELECT id FROM faktury WHERE 1=1'; const arg = [];
  if (st === 'nezaplacene') sql += " AND stav='vystavena'";
  else if (st === 'po_splatnosti') { sql += " AND stav='vystavena' AND splatnost < ?"; arg.push(dnes()); }
  else if (['zaplacena', 'stornovana'].includes(st)) { sql += ' AND stav=?'; arg.push(st); }
  if (hl) { sql += ' AND (cislo LIKE ? OR odberatel LIKE ?)'; arg.push('%' + hl + '%', '%' + hl + '%'); }
  return db.prepare(sql + ' ORDER BY cislo DESC LIMIT 500').all(...arg).map(x => { const f = faktura(x.id); delete f.qr; return f; });
});
r('GET', '/api/faktury/:id', (q, p) => faktura(Number(p.id)));
r('GET', '/api/faktury/ze-zakazky/:zid', (q, p) => {
  const z = zakazka(Number(p.zid)); const platce = nast('firma_platce_dph') !== '0';
  const uz = db.prepare("SELECT cislo FROM faktury WHERE zakazka_id=? AND stav<>'stornovana'").all(z.id).map(x => x.cislo);
  return { zakazka_id: z.id, zakaznik_id: z.zakaznik_id, zaloha: z.zaloha, uz_fakturovano: uz,
    poznamka: `Zakázka ${z.cislo}`,
    polozky: z.polozky.map(x => ({ popis: [x.co, x.prace, x.barva].filter(Boolean).join(' – '), mnozstvi: x.ks, jednotka: 'ks', cena: x.cena, sazba: platce ? 21 : 0 })) };
});
r('GET', '/api/faktury-kontrola', () => {
  const f = firmaTed(); const chyby = [];
  if (!f.nazev) chyby.push('název firmy'); if (!f.ic) chyby.push('IČ'); if (!f.adresa) chyby.push('sídlo');
  if (nast('firma_platce_dph') !== '0' && !f.dic) chyby.push('DIČ (plátce DPH)');
  const u = f.ucet ? rozeberUcet(f.ucet) : null;
  const varovani = [];
  if (!f.ucet && !f.iban) varovani.push('Není vyplněné číslo účtu – faktury nebudou mít platební údaje ani QR platbu.');
  else if (f.ucet && (!u || !u.platne)) varovani.push('Číslo účtu nevypadá jako platný český účet (kontrola modulo 11). Zkontrolujte ho.');
  if (f.iban && !overIban(f.iban)) varovani.push('IBAN nemá správné kontrolní číslice.');
  if (!f.rejstrik) varovani.push('Chybí zápis v obchodním rejstříku (u s.r.o. povinný údaj na faktuře).');
  return { chyby, varovani, iban: f.iban ? formatIban(f.iban) : '' };
});
r('POST', '/api/faktury', async (q) => {
  const v = await telo(q);
  const firma = firmaTed();
  if (!firma.nazev || !firma.ic) throw new Chyba('Nejdřív vyplňte údaje firmy v Nastavení (název a IČ)');
  const platce = nast('firma_platce_dph') !== '0';
  const hl = hlavickaFak(v); const pol = polozkyFak(v.polozky, platce);
  const zid = v.zakazka_id ? zakazka(Number(v.zakazka_id)).id : null;
  return transakce(db, () => {
    const odb = odberatelZ(Number(v.zakaznik_id));
    const vz = jeVzor('zakaznici', Number(v.zakaznik_id));
    const cislo = vz ? dalsiVzorCislo('faktury', 'VZOR-') : dalsiCisloFak(hl.vystaveno.slice(0, 4));
    const zaplacena = v.zaplaceno && hl.zpusob !== 'prevod';
    const rr = db.prepare(`INSERT INTO faktury(cislo, zakazka_id, zakaznik_id, odberatel, dodavatel, platce_dph, vystaveno, duzp, splatnost, zpusob, zaloha, poznamka, stav, zaplaceno_dne, zaplaceno_jak)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(cislo, zid, Number(v.zakaznik_id), JSON.stringify(odb), JSON.stringify(firma), platce ? 1 : 0,
      hl.vystaveno, hl.duzp, hl.splatnost, hl.zpusob, hl.zaloha, hl.poznamka, zaplacena ? 'zaplacena' : 'vystavena', zaplacena ? hl.vystaveno : null, zaplacena ? hl.zpusob : null);
    const id = Number(rr.lastInsertRowid); if (vz) oznacVzor('faktury', id);
    for (const x of pol) db.prepare('INSERT INTO faktury_polozky(faktura_id, popis, mnozstvi, jednotka, cena, sazba, poradi) VALUES (?,?,?,?,?,?,?)').run(id, x.popis, x.mnozstvi, x.jednotka, x.cena, x.sazba, x.poradi);
    syncFaktura(id); return faktura(id);
  });
});
r('PUT', '/api/faktury/:id', async (q, p) => {
  const v = await telo(q); const f = faktura(Number(p.id));
  if (f.stav !== 'vystavena') throw new Chyba('Upravit jde jen nezaplacenou a nestornovanou fakturu');
  const hl = hlavickaFak({ ...f, splatnost: undefined, ...v }); const pol = polozkyFak(v.polozky ?? f.polozky, !!f.platce_dph);
  if (!f.cislo.startsWith('VZOR') && hl.vystaveno.slice(0, 4) !== f.cislo.slice(0, 4)) throw new Chyba('Rok vystavení musí odpovídat číslu faktury');
  return transakce(db, () => {
    const odb = v.zakaznik_id && Number(v.zakaznik_id) !== f.zakaznik_id ? odberatelZ(Number(v.zakaznik_id)) : f.odberatel;
    db.prepare('UPDATE faktury SET zakaznik_id=?, odberatel=?, vystaveno=?, duzp=?, splatnost=?, zpusob=?, zaloha=?, poznamka=? WHERE id=?')
      .run(Number(v.zakaznik_id) || f.zakaznik_id, JSON.stringify(odb), hl.vystaveno, hl.duzp, hl.splatnost, hl.zpusob, hl.zaloha, hl.poznamka, f.id);
    db.prepare('DELETE FROM faktury_polozky WHERE faktura_id=?').run(f.id);
    for (const x of pol) db.prepare('INSERT INTO faktury_polozky(faktura_id, popis, mnozstvi, jednotka, cena, sazba, poradi) VALUES (?,?,?,?,?,?,?)').run(f.id, x.popis, x.mnozstvi, x.jednotka, x.cena, x.sazba, x.poradi);
    syncFaktura(f.id); return faktura(f.id);
  });
});
r('POST', '/api/faktury/:id/zaplaceno', async (q, p) => {
  const v = await telo(q); const f = faktura(Number(p.id));
  if (f.stav !== 'vystavena') throw new Chyba('Faktura už je zaplacená nebo stornovaná');
  const datum = text(v.datum) || dnes(); if (!jeDatum(datum)) throw new Chyba('Datum úhrady není platné');
  db.prepare("UPDATE faktury SET stav='zaplacena', zaplaceno_dne=?, zaplaceno_jak=? WHERE id=?").run(datum, ZPUSOBY[v.jak] ? v.jak : f.zpusob, f.id);
  syncFaktura(f.id); return faktura(f.id);
});
r('POST', '/api/faktury/:id/nezaplaceno', (q, p) => {
  const f = faktura(Number(p.id)); if (f.stav !== 'zaplacena') throw new Chyba('Faktura není zaplacená');
  db.prepare("UPDATE faktury SET stav='vystavena', zaplaceno_dne=NULL, zaplaceno_jak=NULL WHERE id=?").run(f.id); syncFaktura(f.id); return faktura(f.id);
});
r('POST', '/api/faktury/:id/storno', (q, p) => {
  const f = faktura(Number(p.id)); if (f.stav === 'stornovana') throw new Chyba('Faktura už je stornovaná');
  db.prepare("UPDATE faktury SET stav='stornovana' WHERE id=?").run(f.id); syncFaktura(f.id); return faktura(f.id);
});
r('GET', '/qr-platba/:id.svg', (q, p) => { const f = faktura(Number(p.id)); if (!f.qr) throw new Chyba('Faktura nemá QR platbu', 404); return { __svg: qrSvg(f.qr) }; });
function emailFak(f) {
  const s = f.soucty; const kc = (n) => Number(n).toLocaleString('cs-CZ', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' Kč';
  const predmet = `Faktura ${f.cislo} – ${f.dodavatel.nazev}`;
  const telo = ['Dobrý den,', '', `v příloze posíláme fakturu č. ${f.cislo}${f.zakazka_cislo ? ' k zakázce ' + f.zakazka_cislo : ''}.`, '',
    `Částka k úhradě: ${kc(s.k_uhrade)}`, ...(f.zpusob === 'prevod' && f.stav === 'vystavena' ? [`Splatnost: ${new Date(f.splatnost + 'T12:00').toLocaleDateString('cs-CZ')}`,
      `Účet: ${f.dodavatel.ucet || formatIban(f.dodavatel.iban)}`, `Variabilní symbol: ${f.cislo}`] : f.stav === 'zaplacena' ? ['Faktura je již uhrazena, děkujeme.'] : []),
    '', f.dodavatel.text || '', '', `${f.dodavatel.nazev}`, [f.dodavatel.telefon, f.dodavatel.email].filter(Boolean).join(' · ')].join('\n');
  return { komu: f.odberatel.email || '', predmet, telo,
    mailto: `mailto:${encodeURIComponent(f.odberatel.email || '')}?subject=${encodeURIComponent(predmet)}&body=${encodeURIComponent(telo)}` };
}
r('GET', '/api/faktury/:id/email', (q, p) => emailFak(faktura(Number(p.id))));
r('POST', '/api/faktury/:id/pdf', async (q, p) => {
  jenTentoPocitac(q); const f = faktura(Number(p.id));
  return { pdf: await vyrobPdf(`http://127.0.0.1:${PORT}/faktura/${f.id}`, path.join(DATA, 'faktury', `Faktura-${f.cislo}.pdf`)) };
});
r('POST', '/api/faktury/:id/thunderbird', async (q, p) => {
  jenTentoPocitac(q); const f = faktura(Number(p.id)); const e = emailFak(f);
  return doThunderbirdu({ komu: e.komu, predmet: e.predmet, telo: e.telo, url: `http://127.0.0.1:${PORT}/faktura/${f.id}`, slozka: 'faktury', nazev: `Faktura-${f.cislo}` });
});
r('GET', '/faktura/:id', (q, p) => {
  const f = faktura(Number(p.id)); const d = f.dodavatel, o = f.odberatel, s = f.soucty;
  const kc = (n) => Number(n || 0).toLocaleString('cs-CZ', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' Kč';
  const dt = (x) => x ? new Date(x + 'T12:00').toLocaleDateString('cs-CZ') : '';
  const nadpis = f.platce_dph ? 'Faktura – daňový doklad' : 'Faktura';
  const adr = (x) => [x.ulice, [x.psc, x.mesto].filter(Boolean).join(' ')].filter(Boolean).map(h).join('<br>');
  return { __html: `<!doctype html><html lang="cs"><head><meta charset="utf-8"><title>Faktura ${h(f.cislo)}</title><style>
  @page{size:A4;margin:14mm}body{font-family:Arial,Helvetica,sans-serif;font-size:10pt;color:#111;margin:0}
  .hl{display:flex;justify-content:space-between;align-items:flex-start;border-bottom:2px solid #111;padding-bottom:3mm}
  h1{font-size:17pt;margin:0}.c{text-align:right;white-space:nowrap}.mut{color:#555;font-size:9pt}
  .strany{display:grid;grid-template-columns:1fr 1fr;gap:6mm;margin:5mm 0}.box{border:1px solid #bbb;border-radius:2mm;padding:3mm 4mm}
  .box b.t{display:block;font-size:8.5pt;color:#555;text-transform:uppercase;letter-spacing:.3px;margin-bottom:1mm}
  .udaje{display:grid;grid-template-columns:1fr 1fr;gap:6mm;margin-bottom:5mm}.udaje table td{padding:.6mm 0;border:0}
  table.p{width:100%;border-collapse:collapse}table.p th,table.p td{border-bottom:1px solid #ccc;padding:1.8mm;text-align:left;vertical-align:top}
  table.p th{font-size:8.5pt;color:#555;border-bottom:1.5px solid #111}.sum{margin-left:auto;width:55%;margin-top:4mm;border-collapse:collapse}
  .sum td{padding:1.2mm 1.8mm}.sum .k td{font-size:13pt;font-weight:bold;border-top:2px solid #111}
  .storno{color:#b42318;border:3px solid #b42318;display:inline-block;padding:1mm 4mm;font-weight:bold;font-size:16pt;transform:rotate(-4deg)}
  .qr{display:flex;gap:4mm;align-items:center}.qr svg{width:32mm;height:32mm}
  .tl{font:15px system-ui,sans-serif;padding:10px;background:#f3f3f7}.tl button{font:inherit;padding:8px 16px}@media print{.tl{display:none}}</style></head><body>
  <div class="tl"><button onclick="print()">Tisknout / uložit jako PDF</button></div><div style="padding:0 1mm">
  <div class="hl"><div><h1>${nadpis}</h1><div style="font-size:14pt;font-weight:bold">č. ${h(f.cislo)}</div>${f.stav === 'stornovana' ? '<div class="storno">STORNOVÁNO</div>' : ''}</div>
  <img src="/static/logo.png" alt="" style="width:22mm;height:22mm"></div>
  <div class="strany"><div class="box"><b class="t">Dodavatel</b><b>${h(d.nazev)}</b><br>${h(d.adresa)}<br>IČ: ${h(d.ic)}${d.dic ? ' · DIČ: ' + h(d.dic) : ''}<br>${f.platce_dph ? '' : 'Není plátce DPH.<br>'}${d.rejstrik ? `<span class="mut">${h(d.rejstrik)}</span><br>` : ''}${d.provozovna ? `<span class="mut">Provozovna: ${h(d.provozovna)}</span><br>` : ''}<span class="mut">${[d.telefon, d.email].filter(Boolean).map(h).join(' · ')}</span></div>
  <div class="box"><b class="t">Odběratel</b><b>${h(o.nazev)}</b>${o.kontakt ? '<br>' + h(o.kontakt) : ''}<br>${adr(o)}${o.ic ? '<br>IČ: ' + h(o.ic) : ''}${o.dic ? ' · DIČ: ' + h(o.dic) : ''}</div></div>
  <div class="udaje"><table><tr><td>Datum vystavení:</td><td><b>${dt(f.vystaveno)}</b></td></tr>${f.platce_dph ? `<tr><td>Datum uskut. zdanitelného plnění:</td><td><b>${dt(f.duzp)}</b></td></tr>` : ''}<tr><td>Datum splatnosti:</td><td><b>${dt(f.splatnost)}</b></td></tr><tr><td>Způsob úhrady:</td><td><b>${ZPUSOBY[f.zpusob]}</b></td></tr>${f.zakazka_cislo ? `<tr><td>Zakázka:</td><td>${h(f.zakazka_cislo)}</td></tr>` : ''}</table>
  <table>${f.zpusob === 'prevod' ? `<tr><td>Bankovní účet:</td><td><b>${h(d.ucet || '')}</b></td></tr>${d.iban ? `<tr><td>IBAN:</td><td>${h(formatIban(d.iban))}</td></tr>` : ''}${d.banka ? `<tr><td>Banka:</td><td>${h(d.banka)}</td></tr>` : ''}<tr><td>Variabilní symbol:</td><td><b>${h(f.cislo)}</b></td></tr>` : ''}${f.stav === 'zaplacena' ? `<tr><td colspan="2"><b>Uhrazeno ${ZPUSOBY[f.zaplaceno_jak] || ''} dne ${dt(f.zaplaceno_dne)}</b></td></tr>` : ''}</table></div>
  <table class="p"><tr><th>Popis</th><th class="c">Množství</th><th class="c">Cena/j. bez DPH</th>${f.platce_dph ? '<th class="c">DPH</th>' : ''}<th class="c">Celkem bez DPH</th></tr>
  ${f.polozky.map(x => `<tr><td>${h(x.popis)}</td><td class="c">${fmtM(x.mnozstvi)} ${h(x.jednotka || '')}</td><td class="c">${kc(x.cena)}</td>${f.platce_dph ? `<td class="c">${x.sazba} %</td>` : ''}<td class="c">${kc(r2(x.mnozstvi * x.cena))}</td></tr>`).join('')}</table>
  <table class="sum">${f.platce_dph ? s.rekap.map(x => `<tr><td>Základ ${x.sazba} %</td><td class="c">${kc(x.zaklad)}</td></tr><tr><td>DPH ${x.sazba} %</td><td class="c">${kc(x.dph)}</td></tr>`).join('') : ''}
  <tr><td>Celkem${f.platce_dph ? ' s DPH' : ''}</td><td class="c">${kc(s.celkem)}</td></tr>${s.zaokrouhleni ? `<tr><td>Zaokrouhlení</td><td class="c">${kc(s.zaokrouhleni)}</td></tr>` : ''}${s.zaloha ? `<tr><td>Uhrazeno zálohou</td><td class="c">−${kc(s.zaloha)}</td></tr>` : ''}
  <tr class="k"><td>${f.stav === 'zaplacena' ? 'Celkem (uhrazeno)' : 'K úhradě'}</td><td class="c">${kc(s.k_uhrade)}</td></tr></table>
  ${f.qr ? `<div class="qr" style="margin-top:6mm">${qrSvg(f.qr)}<div class="mut">QR Platba – naskenujte v aplikaci své banky.<br>Částka ${kc(s.k_uhrade)}, VS ${h(f.cislo)}</div></div>` : ''}
  ${f.poznamka ? `<p><b>Poznámka:</b> ${h(f.poznamka)}</p>` : ''}${d.text ? `<p>${h(d.text)}</p>` : ''}
  <p class="mut" style="margin-top:8mm">Fakturu vystavil: ${h(d.vystavil || d.nazev)}</p></div></body></html>` };
});

// ---------- peníze: pokladna, náklady, tržby (fáze 5) ----------
// Pravidlo Jiřího (5. 11.): zaplacené faktury a přijatá hotovost (i bez faktury) = plus, vše ostatní = mínus.
const KAT_PRIJEM = { faktura: 'Zaplacená faktura', hotovost: 'Tržba bez faktury', zaloha: 'Záloha na zakázku', ostatni_prijem: 'Ostatní příjem' };
const KAT_VYDEJ = { material: 'Materiál a objednávky', najem: 'Nájem', energie: 'Energie', sluzby: 'Služby a opravy', vybaveni: 'Vybavení a nářadí', ostatni: 'Ostatní' };
const AUTO_KAT = ['faktura', 'zaloha'];
const platceDph = () => nast('firma_platce_dph') !== '0';
const zakladZ = (castka, sazba) => r2(castka / (1 + (sazba || 0) / 100));
function syncFaktura(fid) {
  const f = faktura(fid);
  db.prepare('DELETE FROM penize WHERE faktura_id=?').run(fid);
  if (f.stav !== 'zaplacena' || !(f.soucty.k_uhrade > 0)) return;
  const pomer = f.soucty.celkem_zaokr ? f.soucty.k_uhrade / f.soucty.celkem_zaokr : 1;
  const zaklad = f.platce_dph ? r2(f.soucty.zaklad * pomer) : f.soucty.k_uhrade;
  db.prepare(`INSERT INTO penize(datum, smer, castka, zaklad, sazba, kategorie, popis, hotove, faktura_id) VALUES (?, 'prijem', ?, ?, ?, 'faktura', ?, ?, ?)`)
    .run(f.zaplaceno_dne || f.vystaveno, f.soucty.k_uhrade, zaklad, f.platce_dph ? 21 : 0, `Faktura ${f.cislo} – ${f.odberatel.nazev}`, f.zaplaceno_jak === 'hotove' ? 1 : 0, f.id);
}
function syncZaloha(zid) {
  const z = db.prepare('SELECT z.*, k.nazev AS zakaznik FROM zakazky z JOIN zakaznici k ON k.id=z.zakaznik_id WHERE z.id=?').get(zid);
  db.prepare("DELETE FROM penize WHERE zakazka_id=? AND kategorie='zaloha'").run(zid);
  if (!z || !(z.zaloha > 0) || z.stav === 'zruseno') return;
  const sazba = platceDph() ? 21 : 0;
  db.prepare(`INSERT INTO penize(datum, smer, castka, zaklad, sazba, kategorie, popis, hotove, zakazka_id) VALUES (?, 'prijem', ?, ?, ?, 'zaloha', ?, 1, ?)`)
    .run(z.prijato_dne.slice(0, 10), z.zaloha, zakladZ(z.zaloha, sazba), sazba, `Záloha – zakázka ${z.cislo} (${z.zakaznik})`, z.id);
}
function syncVse() {
  for (const x of db.prepare("SELECT id FROM faktury WHERE stav='zaplacena' AND id NOT IN (SELECT faktura_id FROM penize WHERE faktura_id IS NOT NULL)").all()) syncFaktura(x.id);
  for (const x of db.prepare("SELECT id FROM zakazky WHERE zaloha>0 AND stav<>'zruseno' AND id NOT IN (SELECT zakazka_id FROM penize WHERE kategorie='zaloha')").all()) syncZaloha(x.id);
}
const mesicOk = (m) => /^\d{4}-\d{2}$/.test(m || '');
const konecMesice = (m) => { const [y, mm] = m.split('-').map(Number); return new Date(y, mm, 0).getDate(); };
function ulozPenize(v, id) {
  const smer = v.smer === 'prijem' ? 'prijem' : 'vydej';
  const kat = text(v.kategorie) || (smer === 'prijem' ? 'hotovost' : 'ostatni');
  if (AUTO_KAT.includes(kat)) throw new Chyba('Zaplacené faktury a zálohy se zapisují samy – tady je zadat nejde');
  if (smer === 'prijem' ? !KAT_PRIJEM[kat] : !KAT_VYDEJ[kat]) throw new Chyba('Neznámá kategorie');
  const castka = cislo(v.castka, 'Částka', { povinne: true }); if (!(castka > 0)) throw new Chyba('Částka musí být větší než nula');
  const sazba = cislo(v.sazba, 'Sazba DPH') ?? (platceDph() ? 21 : 0); if (![0, 12, 21].includes(sazba)) throw new Chyba('Sazba DPH může být 21, 12 nebo 0 %');
  const datum = text(v.datum) || dnes(); if (!jeDatum(datum)) throw new Chyba('Datum není platné');
  const hotove = v.hotove === true || v.hotove === 1 || v.hotove === '1' || v.hotove === 'true' ? 1 : 0;
  const h = [datum, smer, castka, zakladZ(castka, sazba), sazba, kat, text(v.popis), hotove, v.objednavka_id ? Number(v.objednavka_id) : null];
  if (id) {
    const st = db.prepare('SELECT * FROM penize WHERE id=?').get(id); if (!st) throw new Chyba('Záznam nenalezen', 404);
    if (AUTO_KAT.includes(st.kategorie)) throw new Chyba('Tento záznam vznikl z faktury nebo zálohy – mění se tam');
    db.prepare('UPDATE penize SET datum=?, smer=?, castka=?, zaklad=?, sazba=?, kategorie=?, popis=?, hotove=?, objednavka_id=? WHERE id=?').run(...h, id);
    return db.prepare('SELECT * FROM penize WHERE id=?').get(id);
  }
  const rr = db.prepare('INSERT INTO penize(datum, smer, castka, zaklad, sazba, kategorie, popis, hotove, objednavka_id) VALUES (?,?,?,?,?,?,?,?,?)').run(...h);
  return db.prepare('SELECT * FROM penize WHERE id=?').get(Number(rr.lastInsertRowid));
}
r('GET', '/api/penize/kategorie', () => ({ prijem: KAT_PRIJEM, vydej: KAT_VYDEJ, platce: platceDph() }));
r('GET', '/api/penize', (q, p, url) => {
  const m = url.searchParams.get('mesic'), smer = url.searchParams.get('smer'), hot = url.searchParams.get('hotove');
  let sql = 'SELECT * FROM penize WHERE 1=1'; const arg = [];
  if (mesicOk(m)) { sql += ' AND datum BETWEEN ? AND ?'; arg.push(m + '-01', `${m}-${konecMesice(m)}`); }
  if (smer === 'prijem' || smer === 'vydej') { sql += ' AND smer=?'; arg.push(smer); }
  if (hot === '1') sql += ' AND hotove=1';
  return db.prepare(sql + ' ORDER BY datum DESC, id DESC LIMIT 1000').all(...arg);
});
r('POST', '/api/penize', async (q) => ulozPenize(await telo(q)));
r('PUT', '/api/penize/:id', async (q, p) => ulozPenize(await telo(q), Number(p.id)));
r('DELETE', '/api/penize/:id', (q, p) => {
  const st = db.prepare('SELECT * FROM penize WHERE id=?').get(Number(p.id)); if (!st) throw new Chyba('Záznam nenalezen', 404);
  if (AUTO_KAT.includes(st.kategorie)) throw new Chyba('Tento záznam vznikl z faktury nebo zálohy – odeberete ho tam');
  db.prepare('DELETE FROM penize WHERE id=?').run(st.id); return { ok: true };
});
r('GET', '/api/pokladna', (q, p, url) => {
  const m = mesicOk(url.searchParams.get('mesic')) ? url.searchParams.get('mesic') : dnes().slice(0, 7);
  const pocatek = Number(String(nast('pokladna_pocatek')).replace(',', '.')) || 0, od = nast('pokladna_pocatek_datum') || '0000-00-00';
  const suma = (smer, doDne) => db.prepare('SELECT coalesce(sum(castka),0) s FROM penize WHERE hotove=1 AND smer=? AND datum>=? AND datum<=?').get(smer, od, doDne).s;
  const konec = `${m}-${konecMesice(m)}`, predtim = `${m}-00`;
  const polozky = db.prepare('SELECT * FROM penize WHERE hotove=1 AND datum BETWEEN ? AND ? ORDER BY datum, id').all(m + '-01', konec);
  return { mesic: m, pocatek, pocatek_datum: nast('pokladna_pocatek_datum'),
    zustatek_zacatek: r2(pocatek + suma('prijem', predtim) - suma('vydej', predtim)),
    prijmy: r2(polozky.filter(x => x.smer === 'prijem').reduce((s, x) => s + x.castka, 0)),
    vydaje: r2(polozky.filter(x => x.smer === 'vydej').reduce((s, x) => s + x.castka, 0)),
    zustatek: r2(pocatek + suma('prijem', konec) - suma('vydej', konec)),
    zustatek_ted: r2(pocatek + suma('prijem', '9999-12-31') - suma('vydej', '9999-12-31')), polozky };
});
// pravidelné platby
r('GET', '/api/pravidelne', () => db.prepare('SELECT * FROM pravidelne WHERE aktivni=1 ORDER BY nazev').all());
const ulozPrav = (v, id) => {
  const nazev = text(v.nazev); if (!nazev) throw new Chyba('Vyplňte název');
  const kat = KAT_VYDEJ[v.kategorie] ? v.kategorie : 'ostatni';
  const castka = cislo(v.castka, 'Částka', { povinne: true }); if (!(castka > 0)) throw new Chyba('Částka musí být větší než nula');
  const sazba = cislo(v.sazba, 'Sazba DPH') ?? 0; if (![0, 12, 21].includes(sazba)) throw new Chyba('Sazba DPH může být 21, 12 nebo 0 %');
  const h = [nazev, castka, sazba, kat, v.hotove ? 1 : 0];
  if (id) { db.prepare('UPDATE pravidelne SET nazev=?, castka=?, sazba=?, kategorie=?, hotove=? WHERE id=?').run(...h, id); return db.prepare('SELECT * FROM pravidelne WHERE id=?').get(id); }
  const rr = db.prepare('INSERT INTO pravidelne(nazev, castka, sazba, kategorie, hotove) VALUES (?,?,?,?,?)').run(...h);
  return db.prepare('SELECT * FROM pravidelne WHERE id=?').get(Number(rr.lastInsertRowid));
};
r('POST', '/api/pravidelne', async (q) => ulozPrav(await telo(q)));
r('PUT', '/api/pravidelne/:id', async (q, p) => ulozPrav(await telo(q), Number(p.id)));
r('DELETE', '/api/pravidelne/:id', (q, p) => { db.prepare('UPDATE pravidelne SET aktivni=0 WHERE id=?').run(Number(p.id)); return { ok: true }; });
r('POST', '/api/pravidelne/zapsat', async (q) => {
  const v = await telo(q); const m = v.mesic; if (!mesicOk(m)) throw new Chyba('Vyberte měsíc');
  let n = 0;
  transakce(db, () => {
    for (const x of db.prepare('SELECT * FROM pravidelne WHERE aktivni=1').all()) {
      const uz = db.prepare('SELECT 1 FROM penize WHERE pravidelna_id=? AND datum BETWEEN ? AND ?').get(x.id, m + '-01', `${m}-${konecMesice(m)}`);
      if (uz) continue;
      db.prepare(`INSERT INTO penize(datum, smer, castka, zaklad, sazba, kategorie, popis, hotove, pravidelna_id) VALUES (?, 'vydej', ?, ?, ?, ?, ?, ?, ?)`)
        .run(m + '-01', x.castka, zakladZ(x.castka, x.sazba), x.sazba, x.kategorie, x.nazev, x.hotove, x.id); n++;
    }
  });
  return { zapsano: n };
});
// objednávka jako náklad
r('POST', '/api/objednavky/:id/naklad', async (q, p) => {
  const v = await telo(q); const o = objednavka(Number(p.id));
  if (db.prepare('SELECT 1 FROM penize WHERE objednavka_id=?').get(o.id)) throw new Chyba('Platba za tuto objednávku už je zapsaná');
  return ulozPenize({ ...v, smer: 'vydej', kategorie: 'material', popis: v.popis || `Objednávka ${o.cislo} – ${o.dodavatel}`, objednavka_id: o.id });
});
// ---------- hodiny ----------
r('GET', '/api/hodiny', (q, p, url) => {
  const m = url.searchParams.get('mesic'), zm = url.searchParams.get('zamestnanec'); let sql = `SELECT h.*, z.jmeno, z.druh, k.cislo AS zakazka_cislo, round(h.hodin*h.sazba,2) AS naklad
    FROM hodiny h JOIN zamestnanci z ON z.id=h.zamestnanec_id LEFT JOIN zakazky k ON k.id=h.zakazka_id WHERE 1=1`; const arg = [];
  if (mesicOk(m)) { sql += ' AND h.datum BETWEEN ? AND ?'; arg.push(m + '-01', `${m}-${konecMesice(m)}`); }
  if (zm) { sql += ' AND h.zamestnanec_id=?'; arg.push(Number(zm)); }
  return db.prepare(sql + ' ORDER BY h.datum DESC, h.id DESC LIMIT 1000').all(...arg);
});
const ulozHod = (v, id) => {
  const z = db.prepare('SELECT * FROM zamestnanci WHERE id=? AND aktivni=1').get(Number(v.zamestnanec_id)); if (!z) throw new Chyba('Vyberte člověka');
  const hodin = cislo(v.hodiny ?? v.hodin, 'Hodiny', { povinne: true }); if (!(hodin > 0 && hodin <= 24)) throw new Chyba('Hodiny musí být mezi 0 a 24');
  const datum = text(v.datum) || dnes(); if (!jeDatum(datum)) throw new Chyba('Datum není platné');
  const zak = v.zakazka_id ? Number(v.zakazka_id) : null; if (zak && !db.prepare('SELECT 1 FROM zakazky WHERE id=?').get(zak)) throw new Chyba('Zakázka neexistuje');
  const sazba = id ? (cislo(v.sazba, 'Sazba') ?? db.prepare('SELECT sazba FROM hodiny WHERE id=?').get(id)?.sazba ?? z.hodinova_sazba) : z.hodinova_sazba;
  const h = [z.id, datum, hodin, sazba, zak, text(v.popis)];
  if (id) { db.prepare('UPDATE hodiny SET zamestnanec_id=?, datum=?, hodin=?, sazba=?, zakazka_id=?, popis=? WHERE id=?').run(...h, id); return db.prepare('SELECT * FROM hodiny WHERE id=?').get(id); }
  const rr = db.prepare('INSERT INTO hodiny(zamestnanec_id, datum, hodin, sazba, zakazka_id, popis) VALUES (?,?,?,?,?,?)').run(...h);
  return db.prepare('SELECT * FROM hodiny WHERE id=?').get(Number(rr.lastInsertRowid));
};
r('POST', '/api/hodiny', async (q) => ulozHod(await telo(q)));
r('PUT', '/api/hodiny/:id', async (q, p) => ulozHod(await telo(q), Number(p.id)));
r('DELETE', '/api/hodiny/:id', (q, p) => { db.prepare('DELETE FROM hodiny WHERE id=?').run(Number(p.id)); return { ok: true }; });
// ---------- zisk ----------
function souhrnObdobi(od, do_) {
  const platce = platceDph(); const pole = platce ? 'zaklad' : 'castka';
  const radky = db.prepare(`SELECT smer, kategorie, sum(${pole}) s, sum(castka) s_dph FROM penize WHERE datum BETWEEN ? AND ? GROUP BY smer, kategorie`).all(od, do_);
  const prijmy = {}, naklady = {};
  for (const x of radky) (x.smer === 'prijem' ? prijmy : naklady)[x.kategorie] = r2(x.s);
  const prace = r2(db.prepare('SELECT coalesce(sum(hodin*sazba),0) s FROM hodiny WHERE datum BETWEEN ? AND ?').get(od, do_).s);
  const hodin = r2(db.prepare('SELECT coalesce(sum(hodin),0) s FROM hodiny WHERE datum BETWEEN ? AND ?').get(od, do_).s);
  const trzby = r2(Object.values(prijmy).reduce((s, x) => s + x, 0));
  const nakladyCelkem = r2(Object.values(naklady).reduce((s, x) => s + x, 0));
  const pr_dph = r2(radky.filter(x => x.smer === 'prijem').reduce((s, x) => s + x.s_dph, 0));
  const vy_dph = r2(radky.filter(x => x.smer === 'vydej').reduce((s, x) => s + x.s_dph, 0));
  return { od, do: do_, bez_dph: platce, prijmy, naklady, trzby, naklady_celkem: nakladyCelkem, prace, hodin, zisk: r2(trzby - nakladyCelkem - prace), prijato_s_dph: pr_dph, vydano_s_dph: vy_dph };
}
r('GET', '/api/zisk', (q, p, url) => {
  const rok = /^\d{4}$/.test(url.searchParams.get('rok') || '') ? url.searchParams.get('rok') : dnes().slice(0, 4);
  const mesice = Array.from({ length: 12 }, (_, i) => { const m = `${rok}-${String(i + 1).padStart(2, '0')}`; return { mesic: m, ...souhrnObdobi(m + '-01', `${m}-${konecMesice(m)}`) }; });
  return { rok, kategorie: { prijem: KAT_PRIJEM, vydej: KAT_VYDEJ }, mesice, celkem: souhrnObdobi(rok + '-01-01', rok + '-12-31') };
});

// ---------- kategorie skladu (volitelné) ----------
r('GET', '/api/kategorie', () => db.prepare(`SELECT k.*, (SELECT count(*) FROM polozky p WHERE p.kategorie_id=k.id AND p.aktivni=1) polozek
  FROM kategorie k WHERE k.aktivni=1 ORDER BY k.poradi, k.nazev`).all());
const ulozKat = (v, id) => {
  const nazev = text(v.nazev); if (!nazev) throw new Chyba('Vyplňte název kategorie');
  const jednotka = text(v.jednotka) || 'kg'; if (!JEDNOTKY.includes(jednotka)) throw new Chyba('Neznámá jednotka');
  const barva = v.barva === true || v.barva === 'true' || v.barva === 1 || v.barva === '1' ? 1 : 0;
  const jina = db.prepare('SELECT id FROM kategorie WHERE nazev=? COLLATE NOCASE AND aktivni=1 AND id<>?').get(nazev, id || 0);
  if (jina) throw new Chyba('Kategorie s tímto názvem už existuje');
  if (id) { db.prepare('UPDATE kategorie SET nazev=?, jednotka=?, barva=? WHERE id=?').run(nazev, jednotka, barva, id); return db.prepare('SELECT * FROM kategorie WHERE id=?').get(id); }
  const stara = db.prepare('SELECT id FROM kategorie WHERE nazev=? COLLATE NOCASE AND aktivni=0').get(nazev);
  if (stara) { db.prepare('UPDATE kategorie SET aktivni=1, jednotka=?, barva=? WHERE id=?').run(jednotka, barva, stara.id); return db.prepare('SELECT * FROM kategorie WHERE id=?').get(stara.id); }
  const poradi = (db.prepare('SELECT coalesce(max(poradi),0)+1 n FROM kategorie').get().n);
  const rr = db.prepare('INSERT INTO kategorie(nazev, jednotka, barva, poradi) VALUES (?,?,?,?)').run(nazev, jednotka, barva, poradi);
  return db.prepare('SELECT * FROM kategorie WHERE id=?').get(Number(rr.lastInsertRowid));
};
r('POST', '/api/kategorie', async (q) => ulozKat(await telo(q)));
r('PUT', '/api/kategorie/:id', async (q, p) => ulozKat(await telo(q), Number(p.id)));
r('DELETE', '/api/kategorie/:id', (q, p) => {
  const n = db.prepare('SELECT count(*) n FROM polozky WHERE kategorie_id=? AND aktivni=1').get(Number(p.id)).n;
  if (n) throw new Chyba(`V kategorii je ${n} položek. Nejdřív je přeřaďte jinam.`);
  db.prepare('UPDATE kategorie SET aktivni=0 WHERE id=?').run(Number(p.id)); return { ok: true };
});

// karta dodavatele: co dodává
r('GET', '/api/dodavatele/:id', (q, p) => {
  const d = db.prepare('SELECT * FROM dodavatele WHERE id=? AND aktivni=1').get(Number(p.id));
  if (!d) throw new Chyba('Dodavatel nenalezen', 404);
  d.polozky = db.prepare(POLOZKA_SQL + ' WHERE p.dodavatel_id=? AND p.aktivni=1 ORDER BY k.poradi, p.nazev').all(d.id);
  d.kategorie = [...new Set(d.polozky.map(x => x.kategorie))];
  return d;
});

// ---------- zákazníci ----------
const ZAK_POLE = ['druh', 'nazev', 'kontakt_osoba', 'ic', 'dic', 'ulice', 'mesto', 'psc', 'email', 'telefon', 'poznamka'];
function ulozZak(v, id) {
  const h = Object.fromEntries(ZAK_POLE.map(k => [k, text(v[k])]));
  h.druh = h.druh === 'firma' ? 'firma' : 'osoba';
  if (!h.nazev) throw new Chyba(h.druh === 'firma' ? 'Vyplňte název firmy' : 'Vyplňte jméno zákazníka');
  if (h.email && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(h.email)) throw new Chyba('E-mail nevypadá správně');
  if (h.ic && !/^\d{8}$/.test(h.ic.replace(/\s/g, ''))) throw new Chyba('IČ má 8 číslic');
  if (h.ic) h.ic = h.ic.replace(/\s/g, '');
  if (id) { db.prepare(`UPDATE zakaznici SET ${ZAK_POLE.map(k => k + '=?').join(',')} WHERE id=?`).run(...ZAK_POLE.map(k => h[k]), id); return db.prepare('SELECT * FROM zakaznici WHERE id=?').get(id); }
  const rr = db.prepare(`INSERT INTO zakaznici(${ZAK_POLE.join(',')}) VALUES (${ZAK_POLE.map(() => '?').join(',')})`).run(...ZAK_POLE.map(k => h[k]));
  return db.prepare('SELECT * FROM zakaznici WHERE id=?').get(Number(rr.lastInsertRowid));
}
r('GET', '/api/zakaznici', (q, p, url) => {
  const s = url.searchParams.get('q');
  if (s) { const l = '%' + s + '%'; return db.prepare('SELECT * FROM zakaznici WHERE aktivni=1 AND (nazev LIKE ? OR kontakt_osoba LIKE ? OR telefon LIKE ? OR email LIKE ? OR ic LIKE ? OR mesto LIKE ?) ORDER BY nazev').all(l, l, l, l, l, l); }
  return db.prepare('SELECT * FROM zakaznici WHERE aktivni=1 ORDER BY nazev').all();
});
r('POST', '/api/zakaznici', async (q) => ulozZak(await telo(q)));
r('PUT', '/api/zakaznici/:id', async (q, p) => ulozZak(await telo(q), Number(p.id)));
r('DELETE', '/api/zakaznici/:id', (q, p) => {
  const id = Number(p.id);
  const v = smazNeboVyrad('zakaznici', id, [[pocet('SELECT count(*) n FROM zakazky WHERE zakaznik_id=?', id), (n) => `má ${n} zakázek`],
    [pocet('SELECT count(*) n FROM faktury WHERE zakaznik_id=?', id), (n) => `má ${n} faktur`]], (r) => `Zákazník ${r.nazev}`);
  if (v.jak === 'smazano') transakce(db, () => { db.prepare('DELETE FROM zakaznici WHERE id=?').run(id); db.prepare("DELETE FROM vzor WHERE tabulka='zakaznici' AND radek=?").run(id); });
  return v;
});

// ---------- zaměstnanci a živnostníci ----------
const ZAM_POLE = ['jmeno', 'druh', 'hodinova_sazba', 'ic', 'telefon', 'email', 'poznamka'];
function ulozZam(v, id) {
  const h = { jmeno: text(v.jmeno), druh: v.druh === 'zivnostnik' ? 'zivnostnik' : 'zamestnanec',
    hodinova_sazba: cislo(v.hodinova_sazba, 'Hodinová sazba') ?? 0, ic: text(v.ic), telefon: text(v.telefon), email: text(v.email), poznamka: text(v.poznamka) };
  if (!h.jmeno) throw new Chyba('Vyplňte jméno');
  if (h.email && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(h.email)) throw new Chyba('E-mail nevypadá správně');
  if (id) { db.prepare(`UPDATE zamestnanci SET ${ZAM_POLE.map(k => k + '=?').join(',')} WHERE id=?`).run(...ZAM_POLE.map(k => h[k]), id); return db.prepare('SELECT * FROM zamestnanci WHERE id=?').get(id); }
  const rr = db.prepare(`INSERT INTO zamestnanci(${ZAM_POLE.join(',')}) VALUES (${ZAM_POLE.map(() => '?').join(',')})`).run(...ZAM_POLE.map(k => h[k]));
  return db.prepare('SELECT * FROM zamestnanci WHERE id=?').get(Number(rr.lastInsertRowid));
}
r('GET', '/api/zamestnanci', () => db.prepare('SELECT * FROM zamestnanci WHERE aktivni=1 ORDER BY jmeno').all());
r('POST', '/api/zamestnanci', async (q) => ulozZam(await telo(q)));
r('PUT', '/api/zamestnanci/:id', async (q, p) => ulozZam(await telo(q), Number(p.id)));
r('DELETE', '/api/zamestnanci/:id', (q, p) => {
  const id = Number(p.id);
  const v = smazNeboVyrad('zamestnanci', id, [[pocet('SELECT count(*) n FROM hodiny WHERE zamestnanec_id=?', id), (n) => `má zapsané hodiny (${n}×), které se počítají do zisku`]], (r) => r.jmeno);
  if (v.jak === 'smazano') transakce(db, () => { db.prepare('DELETE FROM zamestnanci WHERE id=?').run(id); db.prepare("DELETE FROM vzor WHERE tabulka='zamestnanci' AND radek=?").run(id); });
  return v;
});
// Zakázku a objednávku jde smazat jen tehdy, když na ni nic nenavazuje; jinak se ruší (zůstane v evidenci).
r('DELETE', '/api/zakazky/:id', (q, p) => {
  const z = zakazka(Number(p.id));
  const brani = [[pocet('SELECT count(*) n FROM faktury WHERE zakazka_id=?', z.id), 'má fakturu'],
    [pocet('SELECT count(*) n FROM pohyby WHERE zakazka_id=?', z.id), 'má odepsaný materiál'],
    [pocet('SELECT count(*) n FROM hodiny WHERE zakazka_id=?', z.id), 'má zapsané hodiny']].filter(([n]) => n).map(([, t]) => t);
  if (brani.length) throw new Chyba(`Zakázku ${z.cislo} nejde smazat, protože ${brani.join(', ')}. Můžete ji zrušit – zůstane v evidenci jako zrušená.`);
  transakce(db, () => {
    db.prepare('DELETE FROM penize WHERE zakazka_id=?').run(z.id);
    db.prepare('DELETE FROM zakazky_polozky WHERE zakazka_id=?').run(z.id);
    db.prepare('DELETE FROM zakazky WHERE id=?').run(z.id);
    db.prepare("DELETE FROM vzor WHERE tabulka='zakazky' AND radek=?").run(z.id);
  });
  return { ok: true, jak: 'smazano', zprava: `Zakázka ${z.cislo} – smazáno.` };
});
r('DELETE', '/api/objednavky/:id', (q, p) => {
  const o = objednavka(Number(p.id));
  if (!['koncept', 'zruseno'].includes(o.stav)) throw new Chyba(`Objednávku ${o.cislo} nejde smazat – už byla odeslaná. Můžete ji zrušit.`);
  if (pocet('SELECT count(*) n FROM penize WHERE objednavka_id=?', o.id)) throw new Chyba('K objednávce je zapsaná platba – nejdřív ji smažte v Penězích.');
  transakce(db, () => {
    db.prepare('DELETE FROM objednavky_polozky WHERE objednavka_id=?').run(o.id);
    db.prepare('DELETE FROM objednavky WHERE id=?').run(o.id);
    db.prepare("DELETE FROM vzor WHERE tabulka='objednavky' AND radek=?").run(o.id);
  });
  return { ok: true, jak: 'smazano', zprava: `Objednávka ${o.cislo} – smazáno.` };
});

r('GET', '/api/nastaveni', () => Object.fromEntries(db.prepare('SELECT klic, hodnota FROM nastaveni').all().map(x => [x.klic, x.hodnota])));
r('PUT', '/api/nastaveni', async (q) => {
  const v = await telo(q);
  const povolene = ['aktualizace_url', 'stitky_format', 'pokladna_pocatek', 'pokladna_pocatek_datum', 'firma_platce_dph', 'firma_ucet', 'firma_iban', 'firma_banka', 'firma_rejstrik', 'faktura_splatnost', 'faktura_vystavil', 'faktura_text', 'zakazka_ujednani', 'skladne_kc', 'objednavka_text', 'objednavka_zaver', 'firma_nazev', 'firma_ic', 'firma_dic', 'firma_adresa', 'provozovna', 'firma_email', 'firma_telefon', 'zaloha_slozka', 'zaloha_pocet', 'telefon_adresa'];
  transakce(db, () => { for (const k of povolene) if (k in v) db.prepare('INSERT OR REPLACE INTO nastaveni(klic,hodnota) VALUES (?,?)').run(k, String(v[k] ?? '').trim()); });
  if ('zaloha_slozka' in v) { try { fs.mkdirSync(slozkaZaloh(), { recursive: true }); } catch (e) { throw new Chyba('Do složky pro zálohy nejde zapisovat: ' + e.message); } }
  return { ok: true };
});
// Vypnutí kvůli aktualizaci — jen z tohoto počítače, ne z telefonu.
r('POST', '/api/konec', (q) => {
  const z = q.socket.remoteAddress || '';
  if (!['127.0.0.1', '::1', '::ffff:127.0.0.1'].includes(z)) throw new Chyba('Vypnout jde jen z počítače, na kterém program běží', 403);
  setTimeout(() => { try { db.close(); } catch {} process.exit(0); }, 200);
  return { ok: true };
});
// ---------- aktualizace z internetu ----------
// Program v lakovně si stáhne novou verzi sám. Data (Dokumenty) se nemění, před výměnou se udělá záloha.
const VYCHOZI_AKTUALIZACE = 'https://raw.githubusercontent.com/jplasil01-ai/lakujto-crm/main/aktualizace.json';
const INSTALACE = path.dirname(KOREN);
const nainstalovano = () => fs.existsSync(path.join(INSTALACE, 'balicek.json'));
const adresaAktualizaci = () => process.env.LAKUJTO_AKTUALIZACE_URL || nast('aktualizace_url') || VYCHOZI_AKTUALIZACE;
let aktualizujeSe = false;
r('GET', '/api/aktualizace', async () => {
  const zaklad = { verze: VERZE, lze_instalovat: nainstalovano(), adresa: adresaAktualizaci() };
  try {
    const m = await nactiPopis(adresaAktualizaci());
    return { ...zaklad, nova: m.verze, je_nova: novejsi(m.verze, VERZE), poznamka: m.poznamka || '', datum: m.datum || '', velikost: m.velikost || null };
  } catch (e) { return { ...zaklad, chyba: 'Aktualizace se nepodařilo zjistit: ' + (e.name === 'TimeoutError' ? 'internet neodpovídá' : e.message) }; }
});
r('POST', '/api/aktualizace/instaluj', async (q) => {
  jenTentoPocitac(q);
  if (!nainstalovano()) throw new Chyba('Tady běží vývojová kopie programu, ne nainstalovaná – aktualizace jde jen v lakovně');
  if (aktualizujeSe) throw new Chyba('Aktualizace už probíhá');
  aktualizujeSe = true;
  try {
    let m;
    try { m = await nactiPopis(adresaAktualizaci()); } catch (e) { throw new Chyba('Aktualizace se nepodařilo zjistit: ' + e.message); }
    if (!novejsi(m.verze, VERZE)) throw new Chyba(`Máte nejnovější verzi (${VERZE})`);
    let buf;
    try {
      const r = await fetch(m.zip, { signal: AbortSignal.timeout(300e3) });
      if (!r.ok) throw new Error('server odpověděl ' + r.status);
      buf = Buffer.from(await r.arrayBuffer());
    } catch (e) { throw new Chyba('Stažení se nepovedlo: ' + e.message); }
    if (otisk(buf) !== m.sha256) throw new Chyba('Stažený soubor je poškozený (nesouhlasí kontrolní otisk) – nic se nezměnilo, zkuste to znovu');
    const tmp = path.join(os.tmpdir(), `lakujto-aktualizace-${m.verze}-${Date.now()}`);
    try { rozbalZip(buf, tmp); } catch (e) { throw new Chyba('Balíček nejde rozbalit: ' + e.message); }
    const zdroj = path.join(tmp, 'LakujTo CRM');
    const novySrv = path.join(zdroj, 'app', 'server.mjs');
    if (!fs.existsSync(novySrv) || !fs.readFileSync(novySrv, 'utf8').includes(`const VERZE = '${m.verze}'`)) {
      fs.rmSync(tmp, { recursive: true, force: true });
      throw new Chyba('Balíček neobsahuje ohlášenou verzi ' + m.verze + ' – nic se nezměnilo');
    }
    const zaloha = zalohuj('pred-aktualizaci').soubor;
    // Na Windows je běžící node.exe zamčený – aktualizátor proto běží z vlastní kopie (node.exe je samostatný soubor).
    // Jinde se nic nezamyká a kopie by nefungovala (node z Homebrew potřebuje své knihovny vedle sebe).
    let nodeKopie = process.execPath;
    if (process.platform === 'win32') { nodeKopie = path.join(tmp, 'aktualizator-node.exe'); fs.copyFileSync(process.execPath, nodeKopie); }
    fs.copyFileSync(path.join(KOREN, 'aktualizator.mjs'), path.join(tmp, 'aktualizator.mjs'));
    const nodeVCili = path.join(INSTALACE, 'node', 'node.exe');
    const spust = [process.platform === 'win32' && fs.existsSync(nodeVCili) ? nodeVCili : process.execPath, '--no-warnings', path.join(INSTALACE, 'app', 'server.mjs')];
    const log = path.join(DATA, 'aktualizace.log');
    fs.appendFileSync(log, `${new Date().toISOString()} aktualizace ${VERZE} → ${m.verze}, záloha ${zaloha}\n`);
    const p = spawn(nodeKopie, [path.join(tmp, 'aktualizator.mjs'), JSON.stringify({ zdroj, cil: INSTALACE, pid: process.pid, log, spust })],
      { cwd: tmp, detached: true, stdio: 'ignore', windowsHide: true });
    p.unref();
    setTimeout(() => { try { db.close(); } catch {} process.exit(0); }, 300);
    return { ok: true, z: VERZE, na: m.verze, zaloha };
  } catch (e) { aktualizujeSe = false; throw e; }
});
r('GET', '/api/zalohy', () => ({ slozka: slozkaZaloh(), zalohy: seznamZaloh() }));
r('POST', '/api/zalohy', () => zalohuj('rucne'));
r('POST', '/api/zalohy/obnov', async (q) => { const v = await telo(q); obnov(v.soubor); return { ok: true }; });

// ---------- vzorová data ----------
// Při první instalaci (prázdná databáze) program nahraje ukázku označenou [VZOR]. Každý vzorový záznam je
// v tabulce vzor. Co uživatel založí pro vzorového zákazníka/dodavatele, je vzorové taky (čísla VZOR-…,
// nezabírá skutečnou číselnou řadu faktur). Smazání nikdy nevezme nic, na co navazují skutečné záznamy.
const VZ = '[VZOR] ';
const jeVzor = (tab, id) => !!(id && db.prepare('SELECT 1 FROM vzor WHERE tabulka=? AND radek=?').get(tab, Number(id)));
const oznacVzor = (tab, id) => db.prepare('INSERT OR IGNORE INTO vzor(tabulka, radek) VALUES (?,?)').run(tab, Number(id));
function dalsiVzorCislo(tab, prefix) {
  const posl = db.prepare(`SELECT cislo FROM ${tab} WHERE cislo LIKE ? ORDER BY cislo DESC LIMIT 1`).get(prefix + '%');
  return prefix + String(posl ? (Number(posl.cislo.slice(prefix.length)) || 0) + 1 : 1).padStart(3, '0');
}
const VZ_HLAVNI = { // tabulka: odkazy na rodiče
  dodavatele: {}, zakaznici: {}, zamestnanci: {}, pravidelne: {},
  polozky: { dodavatel_id: 'dodavatele' }, objednavky: { dodavatel_id: 'dodavatele' },
  zakazky: { zakaznik_id: 'zakaznici' }, faktury: { zakaznik_id: 'zakaznici', zakazka_id: 'zakazky' },
};
const VZ_LISTY = { // řádky, které patří k něčemu jinému: vlastník (přežije s ním), odkazy, a co se při smazání jen vynuluje
  pohyby: { vlastnik: 'polozka_id', odkazy: { polozka_id: 'polozky', zakazka_id: 'zakazky' }, nulovat: ['zakazka_id'] },
  objednavky_polozky: { vlastnik: 'objednavka_id', odkazy: { objednavka_id: 'objednavky', polozka_id: 'polozky' } },
  zakazky_polozky: { vlastnik: 'zakazka_id', odkazy: { zakazka_id: 'zakazky' } },
  faktury_polozky: { vlastnik: 'faktura_id', odkazy: { faktura_id: 'faktury' } },
  penize: { vlastnik: '*', odkazy: { faktura_id: 'faktury', zakazka_id: 'zakazky', objednavka_id: 'objednavky', pravidelna_id: 'pravidelne' } },
  hodiny: { vlastnik: null, odkazy: { zamestnanec_id: 'zamestnanci', zakazka_id: 'zakazky' }, nulovat: ['zakazka_id'] },
};
const VZ_JMENO = { dodavatele: 'nazev', zakaznici: 'nazev', zamestnanci: 'jmeno', pravidelne: 'nazev', polozky: 'nazev', objednavky: 'cislo', zakazky: 'cislo', faktury: 'cislo' };
const VZ_POPIS = { dodavatele: 'dodavatel', zakaznici: 'zákazník', zamestnanci: 'člověk', pravidelne: 'pravidelná platba', polozky: 'položka skladu', objednavky: 'objednávka', zakazky: 'zakázka', faktury: 'faktura' };
function rozborVzoru() {
  const vz = {}; for (const x of db.prepare('SELECT * FROM vzor').all()) (vz[x.tabulka] ||= new Set()).add(x.radek);
  const keep = {}; const jeV = (t, id) => !!vz[t]?.has(id); const drzi = (t, id) => !!keep[t]?.has(id);
  const prezije = (t, id) => !jeV(t, id) || drzi(t, id);
  const radky = (t, odk) => db.prepare(`SELECT id${Object.keys(odk).map(c => ', ' + c).join('')} FROM ${t}`).all();
  const hl = Object.fromEntries(Object.entries(VZ_HLAVNI).map(([t, o]) => [t, radky(t, o)]));
  const li = Object.fromEntries(Object.entries(VZ_LISTY).map(([t, o]) => [t, radky(t, o.odkazy)]));
  const odkazy = (r, o) => Object.entries(o).filter(([c]) => r[c] != null).map(([c, t]) => [t, Number(r[c]), c]);
  // Řádek přežije, když ukazuje na skutečný (ne vzorový) záznam, nebo když přežije jeho vlastník.
  // Ponechaný vzor sám nedrží jiné vzorové řádky – jinak by jeden podržel řetězem všechno.
  const listPrezije = (t, r) => {
    const L = VZ_LISTY[t], od = odkazy(r, L.odkazy);
    if (od.some(([pt, p]) => !jeV(pt, p))) return true;
    if (L.vlastnik && od.some(([pt, p, c]) => (L.vlastnik === '*' || L.vlastnik === c) && drzi(pt, p))) return true;
    return !jeV(t, r.id) && od.length === 0;
  };
  let zmena = true;
  const podrz = (od, nulovat = []) => { for (const [pt, p, c] of od) if (!nulovat.includes(c) && jeV(pt, p) && !drzi(pt, p)) { (keep[pt] ||= new Set()).add(p); zmena = true; } };
  while (zmena) {
    zmena = false;
    for (const [t, rows] of Object.entries(hl)) for (const r of rows) if (prezije(t, r.id)) podrz(odkazy(r, VZ_HLAVNI[t]));
    for (const [t, rows] of Object.entries(li)) for (const r of rows) if (listPrezije(t, r)) podrz(odkazy(r, VZ_LISTY[t].odkazy), VZ_LISTY[t].nulovat);
  }
  const smazat = {}, vynulovat = [];
  for (const [t, rows] of Object.entries(li)) {
    smazat[t] = rows.filter(r => !listPrezije(t, r)).map(r => r.id);
    for (const r of rows) if (listPrezije(t, r)) for (const c of VZ_LISTY[t].nulovat || []) { const pt = VZ_LISTY[t].odkazy[c]; if (r[c] != null && !prezije(pt, Number(r[c]))) vynulovat.push([t, c, r.id]); }
  }
  for (const t of Object.keys(VZ_HLAVNI)) smazat[t] = hl[t].filter(r => jeV(t, r.id) && !drzi(t, r.id)).map(r => r.id);
  const ponechano = [];
  for (const [t, ids] of Object.entries(keep)) for (const id of ids) {
    const r = db.prepare(`SELECT ${VZ_JMENO[t]} AS j FROM ${t} WHERE id=?`).get(id); if (r) ponechano.push({ tabulka: t, co: VZ_POPIS[t], nazev: r.j });
  }
  const pocet = Object.values(vz).reduce((s, x) => s + x.size, 0);
  return { smazat, vynulovat, ponechano, pocet };
}
function smazVzor() {
  const { smazat, vynulovat, ponechano } = rozborVzoru();
  const celkem = Object.values(smazat).reduce((s, x) => s + x.length, 0);
  if (!celkem) return { smazano: 0, ponechano, zaloha: null };
  const zaloha = zalohuj('pred-smazanim-vzoru').soubor;
  const PORADI = [...Object.keys(VZ_LISTY), 'faktury', 'zakazky', 'objednavky', 'polozky', 'pravidelne', 'zakaznici', 'zamestnanci', 'dodavatele'];
  transakce(db, () => {
    for (const [t, c, id] of vynulovat) db.prepare(`UPDATE ${t} SET ${c}=NULL WHERE id=?`).run(id);
    for (const t of PORADI) for (const id of smazat[t] || []) {
      db.prepare(`DELETE FROM ${t} WHERE id=?`).run(id);
      db.prepare('DELETE FROM vzor WHERE tabulka=? AND radek=?').run(t, id);
    }
    db.prepare("INSERT OR REPLACE INTO nastaveni(klic, hodnota) VALUES ('vzor_stav', ?)").run(ponechano.length ? 'castecne' : 'smazano');
  });
  return { smazano: celkem, ponechano, zaloha };
}
async function nahrajVzor() {
  const A = async (cesta, data, metoda = 'POST') => {
    const r = await fetch(`http://127.0.0.1:${PORT}${cesta}`, { method: metoda, headers: data ? { 'Content-Type': 'application/json' } : {}, body: data ? JSON.stringify(data) : undefined });
    const j = await r.json(); if (!r.ok) throw new Error(`${cesta}: ${j.chyba || r.status}`); return j;
  };
  const o = (t, x) => { oznacVzor(t, x.id); return x; };
  const den = (posun = 0) => { const d = new Date(); d.setDate(d.getDate() + posun); return d.toISOString().slice(0, 10); };
  const pozn = 'Vzorový záznam – po vyzkoušení smažte (lišta nahoře nebo Nápověda).';
  const d1 = o('dodavatele', await A('/api/dodavatele', { nazev: VZ + 'Barvy Novák s.r.o.', kontakt_osoba: 'Jan Novák', email: 'objednavky@example.com', telefon: '+420 600 000 001', poznamka: pozn }));
  const d2 = o('dodavatele', await A('/api/dodavatele', { nazev: VZ + 'Abraziva Plus s.r.o.', email: 'prodej@example.com', poznamka: pozn }));
  o('polozky', await A('/api/polozky', { kategorie_id: 1, nazev: VZ + 'Černá hluboká lesk', ral: 'RAL 9005', povrch: 'lesk', vyrobce: 'Vzorový výrobce', dodavatel_id: d1.id, cena: 310, baleni: 20, pocatecni_stav: 14.5, min_zasoba: 5, tara: 0.8, poznamka: pozn }));
  const p2 = o('polozky', await A('/api/polozky', { kategorie_id: 1, nazev: VZ + 'Stříbrná metalíza na kola', ral: 'RAL 9006', povrch: 'metalíza', vyrobce: 'Vzorový výrobce', dodavatel_id: d1.id, cena: 420, baleni: 20, pocatecni_stav: 2.9, min_zasoba: 5, tara: 0.8, poznamka: pozn }));
  o('polozky', await A('/api/polozky', { kategorie_id: 2, nazev: VZ + 'Korund F36', dodavatel_id: d2.id, cena: 25, baleni: 25, pocatecni_stav: 125, min_zasoba: 50, poznamka: pozn }));
  o('polozky', await A('/api/polozky', { kategorie_id: 3, nazev: VZ + 'Maskovací páska 50 mm', dodavatel_id: d2.id, cena: 89, jednotka: 'ks', pocatecni_stav: 12, min_zasoba: 5, poznamka: pozn }));
  const k1 = o('zakaznici', await A('/api/zakaznici', { druh: 'osoba', nazev: VZ + 'Petr Ukázkový', telefon: '+420 600 000 111', mesto: 'České Budějovice', poznamka: pozn }));
  const k2 = o('zakaznici', await A('/api/zakaznici', { druh: 'firma', nazev: VZ + 'Stavby Ukázka s.r.o.', kontakt_osoba: 'Ing. Ukázka', ulice: 'Vzorová 1', mesto: 'České Budějovice', psc: '370 01', email: 'stavby@example.com', poznamka: pozn }));
  const z1 = o('zamestnanci', await A('/api/zamestnanci', { jmeno: VZ + 'Pavel Lakýrník', druh: 'zamestnanec', hodinova_sazba: 250, poznamka: pozn }));
  const z2 = o('zamestnanci', await A('/api/zamestnanci', { jmeno: VZ + 'Jana Pískovačová', druh: 'zivnostnik', hodinova_sazba: 400, poznamka: pozn }));
  const sl = await A('/api/sluzby', null, 'GET');
  const ren = sl.find(x => /16–17/.test(x.nazev)), rov = sl.find(x => /Rovnání/.test(x.nazev));
  let zk1 = await A('/api/zakazky', { zakaznik_id: k1.id, prevzal: 'Vzor', termin: den(7), informovat: 'sms', souhlas_foto: true, zaloha: 2000, vady: ['koroze', 'opravy'], vady_poznamka: 'Vzorová zakázka – škrábance na dvou kolech.',
    polozky: [{ co: '4× ALU kola 17″', ks: 1, sluzba_id: ren?.id, prace: 'Kompletní renovace', barva: 'RAL 9006 metalíza', cena: ren?.cena || 7200 }, { co: 'Rovnání disku', ks: 1, sluzba_id: rov?.id, cena: rov?.cena || 900 }] });
  await A(`/api/zakazky/${zk1.id}/stav`, { stav: 'v_praci' });
  await A(`/api/zakazky/${zk1.id}/spotreba`, { polozka_id: p2.id, mnozstvi: 0.8 });
  let zk2 = await A('/api/zakazky', { zakaznik_id: k2.id, prevzal: 'Vzor', termin: den(-2), informovat: 'email', polozky: [{ co: 'Ocelové zábradlí 3 m', ks: 1, prace: 'Pískování + prášková barva', barva: 'RAL 9005 lesk', cena: 4800 }] });
  await A(`/api/zakazky/${zk2.id}/stav`, { stav: 'v_praci' }); await A(`/api/zakazky/${zk2.id}/stav`, { stav: 'hotovo' });
  const fv = await A('/api/faktury/ze-zakazky/' + zk2.id, null, 'GET');
  const f = await A('/api/faktury', { ...fv, vystaveno: den(-1) });
  await A(`/api/faktury/${f.id}/zaplaceno`, { datum: den() });
  await A('/api/objednavky', { dodavatel_id: d1.id, polozky: [{ polozka_id: p2.id, mnozstvi: 20 }], poznamka: 'Vzorová objednávka – nic se neodešle, dokud ji nepošlete.' });
  await A('/api/hodiny', { zamestnanec_id: z1.id, hodiny: 6, datum: den(), zakazka_id: zk1.id, popis: 'Vzor' });
  await A('/api/hodiny', { zamestnanec_id: z2.id, hodiny: 4, datum: den(-1), zakazka_id: zk2.id, popis: 'Vzor' });
  o('penize', await A('/api/penize', { smer: 'prijem', kategorie: 'hotovost', castka: 1500, hotove: 1, datum: den(), popis: VZ + 'Lakování rámu kola – bez faktury' }));
  o('penize', await A('/api/penize', { smer: 'vydej', kategorie: 'material', castka: 450, hotove: 1, datum: den(), popis: VZ + 'Ředidlo a hadry' }));
  o('pravidelne', await A('/api/pravidelne', { nazev: VZ + 'Nájem dílny', castka: 15000, kategorie: 'najem', sazba: 0 }));
  db.prepare("INSERT OR REPLACE INTO nastaveni(klic, hodnota) VALUES ('vzor_stav', 'nahrano')").run();
  return { pocet: rozborVzoru().pocet };
}
const prazdnaDb = () => !nast('vzor_stav') && !['polozky', 'zakaznici', 'dodavatele', 'zakazky', 'faktury'].some(t => db.prepare(`SELECT 1 FROM ${t} LIMIT 1`).get());
r('GET', '/api/vzor', () => { const x = rozborVzoru(); return { pocet: x.pocet, stav: nast('vzor_stav') || '', ke_smazani: Object.values(x.smazat).reduce((s, a) => s + a.length, 0), ponechano: x.ponechano }; });
r('POST', '/api/vzor/smazat', () => smazVzor());
r('POST', '/api/vzor/nahrat', async () => {
  if (rozborVzoru().pocet) throw new Chyba('Vzorová data už v programu jsou');
  return nahrajVzor();
});

// QR a štítky
// Formáty: arch A4 pro kancelářskou tiskárnu, nebo role Brother QL (QL-800 a podobné, šíře 62 mm) – jeden štítek = jedna stránka.
const FORMATY_STITKU = {
  a4: 'Arch A4 (3 × 7 štítků 63,5 × 38,1 mm)',
  ql62x100: 'Brother QL – 62 × 100 mm (role DK-11202, nebo nekonečná 62 mm)',
  ql62x29: 'Brother QL – 62 × 29 mm (role DK-11209)',
};
function stitkyRole(rows, fmt) {
  const velky = fmt === 'ql62x100';
  const [w, v] = velky ? [62, 100] : [62, 29];
  const qr = (x) => qrSvg(`${adresaProTelefon()}/m/${encodeURIComponent(x.kod)}`);
  const stitek = velky
    ? (x) => `<div class="s"><div class="hl"><img src="/static/logo.png" alt=""><span>${h(x.kod)}</span></div>
      <div class="n">${h(x.nazev)}</div>${x.ral || x.povrch ? `<div class="ral">${h(x.ral || '')} ${h(x.povrch || '')}</div>` : `<div class="r">${h(x.kategorie)}</div>`}
      <div class="q">${qr(x)}</div>
      ${x.vyrobce ? `<div class="r">Výrobce: ${h(x.vyrobce)}</div>` : ''}<div class="r"><b>Dodavatel:</b> ${h(x.dodavatel || '–')}</div>
      ${x.kod_dodavatele ? `<div class="r">Kód dod.: ${h(x.kod_dodavatele)}</div>` : ''}</div>`
    : (x) => `<div class="s"><div class="q">${qr(x)}</div><div class="t"><div class="n">${h(x.nazev)}</div>
      ${x.ral || x.povrch ? `<div class="ral">${h(x.ral || '')} ${h(x.povrch || '')}</div>` : ''}<div class="r">${h(x.dodavatel || '–')}</div>
      <div class="k"><img src="/static/logo.png" alt="">${h(x.kod)}</div></div></div>`;
  const css = velky
    ? `.s{padding:3mm 3.5mm;display:flex;flex-direction:column;align-items:center;text-align:center;gap:1mm}
      .hl{display:flex;align-items:center;gap:2mm;font-size:13pt;font-weight:bold;letter-spacing:.4px}.hl img{width:9mm;height:9mm}
      .n{font-size:14pt;font-weight:bold;line-height:1.15;max-height:2.35em;overflow:hidden}.ral{font-size:16pt;font-weight:bold}
      .q svg{width:42mm;height:42mm;display:block}.r{font-size:10pt;line-height:1.2;max-width:100%;max-height:2.4em;overflow:hidden}`
    : `.s{padding:1.5mm 2mm;display:flex;align-items:center;gap:2mm}.q svg{width:25mm;height:25mm;display:block}
      .t{min-width:0;overflow:hidden;font-size:8pt;line-height:1.15}.n{font-size:9.5pt;font-weight:bold;max-height:2.3em;overflow:hidden}
      .ral{font-size:10pt;font-weight:bold}.r{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
      .k{font-size:9pt;font-weight:bold;display:flex;align-items:center;gap:1mm;margin-top:.5mm}.k img{width:5mm;height:5mm}`;
  return `<!doctype html><html lang="cs"><head><meta charset="utf-8"><title>Štítky LakujTo</title><style>
  @page{size:${w}mm ${v}mm;margin:0}html,body{margin:0;font-family:Arial,sans-serif;color:#000}
  .s{width:${w}mm;height:${v}mm;box-sizing:border-box;overflow:hidden;break-after:page;page-break-after:always}.s:last-child{break-after:auto;page-break-after:auto}
  ${css}
  .tl{font:15px system-ui,sans-serif;padding:10px;max-width:640px}.tl button{font:inherit;padding:8px 16px}
  @media screen{body{background:#eee}.s{background:#fff;margin:10px;box-shadow:0 1px 4px #0003}}
  @media print{.tl{display:none}}</style></head><body>
  <div class="tl"><button onclick="print()">Tisknout</button> ${h(FORMATY_STITKU[fmt])}. Vyberte tiskárnu Brother, velikost papíru ${w} × ${v} mm (u nekonečné role „62 mm“), okraje žádné, měřítko 100 %.</div>
  ${rows.map(stitek).join('')}</body></html>`;
}
r('GET', '/api/stitky/formaty', () => ({ formaty: FORMATY_STITKU, vybrany: FORMATY_STITKU[nast('stitky_format')] ? nast('stitky_format') : 'a4' }));
r('GET', '/qr/:kod.svg', (q, p) => ({ __svg: qrSvg(`${adresaProTelefon()}/m/${encodeURIComponent(p.kod)}`) }));
const h = (s) => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
r('GET', '/stitky', (q, p, url) => {
  const ids = (url.searchParams.get('ids') || '').split(',').map(Number).filter(Boolean);
  const rows = ids.length ? db.prepare(POLOZKA_SQL + ` WHERE p.id IN (${ids.map(() => '?').join(',')}) ORDER BY k.poradi, p.nazev`).all(...ids) : [];
  const stitek = (x) => `<div class="s">${qrSvg(`${adresaProTelefon()}/m/${encodeURIComponent(x.kod)}`)}<div class="t">
    <span class="n">${h(x.nazev)}</span>${x.ral || x.povrch ? `<span class="ral">${h(x.ral || '')} ${h(x.povrch || '')}</span>` : `<span class="r">${h(x.kategorie)}</span>`}
    ${x.vyrobce ? `<span class="r">Výrobce: ${h(x.vyrobce)}</span>` : ''}<span class="r">Dodavatel: ${h(x.dodavatel || '–')}</span>
    ${x.kod_dodavatele ? `<span class="r">Kód dod.: ${h(x.kod_dodavatele)}</span>` : ''}<div class="k"><img src="/static/logo.png" alt="">${h(x.kod)}</div></div></div>`;
  const fmt = FORMATY_STITKU[url.searchParams.get('format')] ? url.searchParams.get('format') : (FORMATY_STITKU[nast('stitky_format')] ? nast('stitky_format') : 'a4');
  if (fmt !== 'a4') return { __html: stitkyRole(rows, fmt) };
  return { __html: `<!doctype html><html lang="cs"><head><meta charset="utf-8"><title>Štítky LakujTo</title><style>
  @page{size:A4;margin:15.15mm 7.2mm}body{margin:0;font-family:Arial,sans-serif}
  .arch{display:grid;grid-template-columns:repeat(3,63.5mm);grid-auto-rows:38.1mm;column-gap:2.5mm}
  .s{display:flex;align-items:center;gap:2mm;padding:1.5mm 2.5mm;overflow:hidden;box-sizing:border-box;border:1px dashed #ccc}
  .s svg{width:24mm;height:24mm;flex:none}.t{font-size:8pt;line-height:1.18;min-width:0;overflow:hidden}
  .t .n{font-size:10pt;font-weight:bold;display:block;max-height:2.4em;overflow:hidden}.t .ral{font-size:11pt;font-weight:bold;display:block;margin:.4mm 0}
  .t .r{display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.k{font-size:10pt;font-weight:bold;margin-top:.6mm;letter-spacing:.3px;display:flex;align-items:center;gap:1.5mm}.k img{width:7mm;height:7mm}
  .tl{font:15px system-ui,sans-serif;padding:10px}.tl button{font:inherit;padding:8px 16px}
  @media print{.s{border:0}.tl{display:none}}</style></head><body>
  <div class="tl"><button onclick="print()">Tisknout</button> Arch A4, 3 × 7 štítků 63,5 × 38,1 mm. Při tisku nastavte měřítko 100 %.</div>
  <div class="arch">${rows.map(stitek).join('')}</div></body></html>` };
});

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x');
  try {
    if (req.method === 'GET' && (url.pathname === '/' || url.pathname === '/index.html')) return staticky(res, 'index.html');
    if (req.method === 'GET' && (url.pathname === '/m' || url.pathname.startsWith('/m/'))) return staticky(res, 'mobil.html');
    if (req.method === 'GET' && url.pathname.startsWith('/static/')) return staticky(res, url.pathname.slice(8));
    for (const rt of ROUTY) {
      const m = rt.metoda === req.method && url.pathname.match(rt.re);
      if (m) {
        const out = await rt.fn(req, m.groups || {}, url);
        if (out && out.__svg) return posli(res, 200, out.__svg, 'image/svg+xml');
        if (out && out.__html) return posli(res, 200, out.__html, 'text/html; charset=utf-8');
        return posli(res, 200, out ?? { ok: true });
      }
    }
    posli(res, 404, { chyba: 'Nenalezeno' });
  } catch (e) {
    if (!(e instanceof Chyba)) console.error(e);
    posli(res, e.kod || 500, { chyba: e instanceof Chyba ? e.message : 'Chyba programu: ' + e.message });
  }
});

server.on('error', (e) => {
  if (e.code === 'EADDRINUSE') { console.log(`Program už běží (port ${PORT}).`); process.exit(3); }
  throw e;
});
server.listen(PORT, '0.0.0.0', () => {
  console.log(`LakujTo CRM ${VERZE} běží: http://localhost:${PORT}  telefon: ${adresaProTelefon()}  data: ${DB_SOUBOR}`);
  zalohujKdyzJeCas();
  try { syncVse(); } catch (e) { console.error('Dopočet tržeb selhal:', e.message); }
  if (process.env.LAKUJTO_VZOR !== '0' && prazdnaDb()) nahrajVzor().then(x => console.log(`Nahrána vzorová data (${x.pocet} záznamů).`), e => console.error('Vzorová data se nenahrála:', e.message));
  setInterval(zalohujKdyzJeCas, 3600e3).unref();
  // úklid po aktualizaci (dočasné složky se staženou verzí a kopií node.exe)
  // (jen složky starší než hodina a nikdy během běžící aktualizace – jinak by smazal právě stahovanou verzi)
  setTimeout(() => { try { if (aktualizujeSe) return; for (const f of fs.readdirSync(os.tmpdir())) { const p = path.join(os.tmpdir(), f); if (f.startsWith('lakujto-aktualizace-') && Date.now() - fs.statSync(p).mtimeMs > 3600e3) fs.rmSync(p, { recursive: true, force: true }); } } catch {} }, Number(process.env.LAKUJTO_UKLID_MS) || 30e3).unref();
});
