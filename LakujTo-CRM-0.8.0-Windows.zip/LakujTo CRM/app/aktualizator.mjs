// LakujTo CRM — výměna programu za novou verzi. Spouští ho server z dočasné složky (vlastní kopií node),
// takže soubory programu nejsou nic zamčené. Data v Dokumentech nikdy neotevírá.
// Postup: počkat, až starý program skončí → app a node přejmenovat na *.predchozi → nakopírovat nové
// → spustit program. Když cokoli selže, vrátí předchozí verzi a spustí ji.
// argumenty: JSON { zdroj, cil, pid, log, spust: [prikaz, ...argumenty] }
import fs from 'node:fs';
import path from 'node:path';
import { spawn } from 'node:child_process';

const a = JSON.parse(process.argv[2]);
const zapis = (t) => { try { fs.appendFileSync(a.log, `${new Date().toISOString()} ${t}\n`); } catch {} };
const zije = (pid) => { try { process.kill(pid, 0); return true; } catch (e) { return e.code === 'EPERM'; } };
const spi = (ms) => new Promise(r => setTimeout(r, ms));

async function vymen() {
  for (let i = 0; i < 300 && zije(a.pid); i++) await spi(100);
  if (zije(a.pid)) throw new Error('starý program se nevypnul');
  await spi(500); // Windows pouští zámky souborů se zpožděním
  // nejdřív složky (app, node), soubory až potom – když výměna složky selže, nic dalšího se nezměnilo
  const slozky = fs.readdirSync(a.zdroj, { withFileTypes: true }).sort((x, y) => y.isDirectory() - x.isDirectory());
  const vymenene = [];
  try {
    for (const s of slozky) {
      const z = path.join(a.zdroj, s.name), c = path.join(a.cil, s.name);
      if (s.isDirectory()) {
        const stara = c + '.predchozi';
        if (fs.existsSync(c)) {
          fs.rmSync(stara, { recursive: true, force: true });
          let ok = false;
          for (let i = 0; i < 20 && !ok; i++) { try { fs.renameSync(c, stara); ok = true; } catch (e) { if (i === 19) throw e; await spi(500); } }
          vymenene.push(s.name);
        }
        fs.cpSync(z, c, { recursive: true });
      } else fs.copyFileSync(z, c);
    }
  } catch (e) {
    zapis('CHYBA při kopírování: ' + e.message + ' — vracím předchozí verzi');
    for (const jm of vymenene) {
      const c = path.join(a.cil, jm);
      try { fs.rmSync(c, { recursive: true, force: true }); fs.renameSync(c + '.predchozi', c); } catch (e2) { zapis('návrat ' + jm + ' selhal: ' + e2.message); }
    }
    throw e;
  }
  zapis('vyměněno: ' + slozky.map(s => s.name).join(', '));
}

try { await vymen(); } catch (e) { zapis('aktualizace NEPROBĚHLA: ' + e.message); }
const p = spawn(a.spust[0], a.spust.slice(1), { cwd: a.cil, detached: true, stdio: 'ignore', windowsHide: true });
p.unref();
zapis('program spuštěn');
setTimeout(() => { try { fs.rmSync(a.zdroj, { recursive: true, force: true }); } catch {} process.exit(0); }, 300);
