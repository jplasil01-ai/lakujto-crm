// LakujTo CRM — výpočty faktur (čisté funkce, bez databáze): DPH, zaokrouhlení, IBAN, QR Platba.

export const r2 = (n) => Math.round((Number(n) + Number.EPSILON) * 100) / 100;

// Součty faktury. U plátce DPH se daň počítá za každou sazbu z jejího základu (rekapitulace).
// U hotovosti se celková částka zaokrouhlí na celé koruny (zákon o oběhu bankovek a mincí).
export function soucty(polozky, { platce = true, zpusob = 'prevod', zaloha = 0 } = {}) {
  const sazby = new Map();
  for (const p of polozky) {
    const s = platce ? Number(p.sazba ?? 21) : 0;
    const zaklad = r2(Number(p.mnozstvi ?? 1) * Number(p.cena ?? 0));
    sazby.set(s, r2((sazby.get(s) || 0) + zaklad));
  }
  const rekap = [...sazby.entries()].sort((a, b) => b[0] - a[0])
    .map(([sazba, zaklad]) => ({ sazba, zaklad, dph: r2(zaklad * sazba / 100), celkem: r2(zaklad + r2(zaklad * sazba / 100)) }));
  const zaklad = r2(rekap.reduce((s, x) => s + x.zaklad, 0));
  const dph = r2(rekap.reduce((s, x) => s + x.dph, 0));
  const celkem = r2(zaklad + dph);
  const zaokrouhleni = zpusob === 'hotove' ? r2(Math.round(celkem) - celkem) : 0;
  const celkem_zaokr = r2(celkem + zaokrouhleni);
  const k_uhrade = r2(Math.max(0, celkem_zaokr - (Number(zaloha) || 0)));
  return { rekap, zaklad, dph, celkem, zaokrouhleni, celkem_zaokr, zaloha: r2(Number(zaloha) || 0), k_uhrade };
}

// Kontrola českého čísla účtu (vážený součet mod 11) — prefix i číslo zvlášť.
function mod11(cislo, vahy) {
  const c = cislo.padStart(vahy.length, '0');
  let s = 0; for (let i = 0; i < vahy.length; i++) s += Number(c[i]) * vahy[i];
  return s % 11 === 0;
}
export function rozeberUcet(text) {
  const m = String(text || '').replace(/\s/g, '').match(/^(?:(\d{1,6})-)?(\d{2,10})\/(\d{4})$/);
  if (!m) return null;
  const [, prefix = '', cislo, banka] = m;
  const platne = (!prefix || mod11(prefix, [10, 5, 8, 4, 2, 1])) && mod11(cislo, [6, 3, 7, 9, 10, 5, 8, 4, 2, 1]);
  return { prefix, cislo, banka, platne };
}
// IBAN z českého čísla účtu: CZ + kontrolní číslice + kód banky (4) + předčíslí (6) + číslo (10)
export function ibanZUctu(text) {
  const u = rozeberUcet(text); if (!u) return null;
  const bban = u.banka + u.prefix.padStart(6, '0') + u.cislo.padStart(10, '0');
  return 'CZ' + String(98 - mod97(bban + '123500')).padStart(2, '0') + bban;
}
function mod97(cisla) { let z = 0; for (const ch of cisla) z = (z * 10 + Number(ch)) % 97; return z; }
export function overIban(iban) {
  const s = String(iban || '').replace(/\s/g, '').toUpperCase();
  if (!/^[A-Z]{2}\d{2}[A-Z0-9]{10,30}$/.test(s)) return false;
  const p = (s.slice(4) + s.slice(0, 4)).replace(/[A-Z]/g, (c) => String(c.charCodeAt(0) - 55));
  return mod97(p) === 1;
}
export const formatIban = (iban) => String(iban || '').replace(/\s/g, '').replace(/(.{4})/g, '$1 ').trim();

// QR Platba (SPAYD 1.0, Česká bankovní asociace)
export function spayd({ iban, castka, vs, zprava, splatnost }) {
  const cista = (t, max) => String(t || '').replace(/\*/g, ' ').normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^\x20-\x7E]/g, '-').slice(0, max);
  const casti = ['SPD', '1.0', `ACC:${String(iban).replace(/\s/g, '').toUpperCase()}`, `AM:${Number(castka).toFixed(2)}`, 'CC:CZK'];
  if (splatnost) casti.push(`DT:${String(splatnost).replace(/-/g, '')}`);
  if (vs) casti.push(`X-VS:${String(vs).replace(/\D/g, '').slice(0, 10)}`);
  if (zprava) casti.push(`MSG:${cista(zprava, 60)}`);
  return casti.join('*');
}
