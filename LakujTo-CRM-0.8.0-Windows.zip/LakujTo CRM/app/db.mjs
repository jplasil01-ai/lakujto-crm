// LakujTo CRM — databáze (SQLite vestavěné v Node, žádná instalace navíc).
import { DatabaseSync } from 'node:sqlite';
import fs from 'node:fs';
import path from 'node:path';

const MIGRACE = [
  // 1 — fáze 1: sklad a dodavatelé
  `
  CREATE TABLE dodavatele (
    id INTEGER PRIMARY KEY,
    nazev TEXT NOT NULL,
    kontakt_osoba TEXT, email TEXT, telefon TEXT, web TEXT, ic TEXT, poznamka TEXT,
    aktivni INTEGER NOT NULL DEFAULT 1,
    vytvoreno TEXT NOT NULL DEFAULT (datetime('now','localtime'))
  );
  CREATE TABLE polozky (
    id INTEGER PRIMARY KEY,
    kod TEXT UNIQUE,
    typ TEXT NOT NULL CHECK (typ IN ('barva','abrazivo','material')),
    nazev TEXT NOT NULL,
    vyrobce TEXT, dodavatel_id INTEGER REFERENCES dodavatele(id),
    kod_dodavatele TEXT, ral TEXT, povrch TEXT,
    jednotka TEXT NOT NULL DEFAULT 'kg',
    baleni REAL, cena REAL, min_zasoba REAL NOT NULL DEFAULT 0,
    tara REAL NOT NULL DEFAULT 0,
    umisteni TEXT, poznamka TEXT,
    stav REAL NOT NULL DEFAULT 0,
    aktivni INTEGER NOT NULL DEFAULT 1,
    vytvoreno TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    upraveno TEXT NOT NULL DEFAULT (datetime('now','localtime'))
  );
  CREATE TABLE pohyby (
    id INTEGER PRIMARY KEY,
    polozka_id INTEGER NOT NULL REFERENCES polozky(id),
    cas TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    typ TEXT NOT NULL CHECK (typ IN ('prijem','vydej','vazeni','oprava')),
    zmena REAL NOT NULL, stav_po REAL NOT NULL,
    hruba REAL, pocet_obalu INTEGER,
    poznamka TEXT, zdroj TEXT NOT NULL DEFAULT 'pc'
  );
  CREATE INDEX pohyby_polozka ON pohyby(polozka_id, cas);
  CREATE TABLE nastaveni (klic TEXT PRIMARY KEY, hodnota TEXT);
  INSERT INTO nastaveni(klic, hodnota) VALUES
    ('firma_nazev','GP novum s.r.o.'), ('firma_ic','28155483'), ('firma_dic','CZ28155483'),
    ('firma_adresa','Riegrova 1756/51, 370 01 České Budějovice'),
    ('provozovna','LakujTo – Novohradská 1764, 370 01 České Budějovice 6'),
    ('firma_email','info@lakujto.cz'), ('firma_telefon','+420 721 323 031'),
    ('zaloha_slozka',''), ('zaloha_pocet','30');
  `,
  // 2 — kategorie skladu volitelné (místo pevných tří typů), zákazníci, zaměstnanci
  `
  CREATE TABLE kategorie (
    id INTEGER PRIMARY KEY,
    nazev TEXT NOT NULL UNIQUE COLLATE NOCASE,
    jednotka TEXT NOT NULL DEFAULT 'kg',
    barva INTEGER NOT NULL DEFAULT 0,
    poradi INTEGER NOT NULL DEFAULT 0,
    aktivni INTEGER NOT NULL DEFAULT 1
  );
  INSERT INTO kategorie(id, nazev, jednotka, barva, poradi) VALUES
    (1,'Barvy','kg',1,1), (2,'Abrazivo','kg',0,2), (3,'Spotřební materiál','ks',0,3);
  CREATE TABLE polozky2 (
    id INTEGER PRIMARY KEY,
    kod TEXT UNIQUE,
    kategorie_id INTEGER NOT NULL REFERENCES kategorie(id),
    nazev TEXT NOT NULL,
    vyrobce TEXT, dodavatel_id INTEGER REFERENCES dodavatele(id),
    kod_dodavatele TEXT, ral TEXT, povrch TEXT,
    jednotka TEXT NOT NULL DEFAULT 'kg',
    baleni REAL, cena REAL, min_zasoba REAL NOT NULL DEFAULT 0,
    tara REAL NOT NULL DEFAULT 0,
    umisteni TEXT, poznamka TEXT,
    stav REAL NOT NULL DEFAULT 0,
    aktivni INTEGER NOT NULL DEFAULT 1,
    vytvoreno TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    upraveno TEXT NOT NULL DEFAULT (datetime('now','localtime'))
  );
  INSERT INTO polozky2 SELECT id, kod, CASE typ WHEN 'barva' THEN 1 WHEN 'abrazivo' THEN 2 ELSE 3 END,
    nazev, vyrobce, dodavatel_id, kod_dodavatele, ral, povrch, jednotka, baleni, cena, min_zasoba, tara,
    umisteni, poznamka, stav, aktivni, vytvoreno, upraveno FROM polozky;
  DROP TABLE polozky;
  ALTER TABLE polozky2 RENAME TO polozky;
  CREATE INDEX polozky_dodavatel ON polozky(dodavatel_id);
  CREATE TABLE zakaznici (
    id INTEGER PRIMARY KEY,
    druh TEXT NOT NULL DEFAULT 'osoba' CHECK (druh IN ('osoba','firma')),
    nazev TEXT NOT NULL, kontakt_osoba TEXT,
    ic TEXT, dic TEXT, ulice TEXT, mesto TEXT, psc TEXT,
    email TEXT, telefon TEXT, poznamka TEXT,
    aktivni INTEGER NOT NULL DEFAULT 1,
    vytvoreno TEXT NOT NULL DEFAULT (datetime('now','localtime'))
  );
  CREATE TABLE zamestnanci (
    id INTEGER PRIMARY KEY,
    jmeno TEXT NOT NULL,
    druh TEXT NOT NULL DEFAULT 'zamestnanec' CHECK (druh IN ('zamestnanec','zivnostnik')),
    hodinova_sazba REAL NOT NULL DEFAULT 0,
    ic TEXT, telefon TEXT, email TEXT, poznamka TEXT,
    aktivni INTEGER NOT NULL DEFAULT 1,
    vytvoreno TEXT NOT NULL DEFAULT (datetime('now','localtime'))
  );
  `,
  // 3 — fáze 2: objednávky u dodavatelů
  `
  CREATE TABLE objednavky (
    id INTEGER PRIMARY KEY,
    cislo TEXT UNIQUE NOT NULL,
    dodavatel_id INTEGER NOT NULL REFERENCES dodavatele(id),
    stav TEXT NOT NULL DEFAULT 'koncept' CHECK (stav IN ('koncept','odeslano','prijato','zruseno')),
    poznamka TEXT,
    vytvoreno TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    odeslano TEXT, prijato TEXT
  );
  CREATE TABLE objednavky_polozky (
    id INTEGER PRIMARY KEY,
    objednavka_id INTEGER NOT NULL REFERENCES objednavky(id) ON DELETE CASCADE,
    polozka_id INTEGER NOT NULL REFERENCES polozky(id),
    mnozstvi REAL NOT NULL CHECK (mnozstvi > 0),
    cena REAL,
    prijato REAL
  );
  CREATE INDEX objpol_obj ON objednavky_polozky(objednavka_id);
  INSERT OR IGNORE INTO nastaveni(klic, hodnota) VALUES
    ('objednavka_text', 'Dobrý den,\nobjednáváme u Vás následující zboží. Prosíme o potvrzení objednávky a termínu dodání.'),
    ('objednavka_zaver', 'Děkujeme a přejeme hezký den.');
  `,
  // 4 — fáze 3: ceník služeb, zakázky, spotřeba materiálu na zakázku
  `
  CREATE TABLE sluzby (
    id INTEGER PRIMARY KEY, nazev TEXT NOT NULL, jednotka TEXT NOT NULL DEFAULT 'ks',
    cena REAL NOT NULL DEFAULT 0, poradi INTEGER NOT NULL DEFAULT 0, aktivni INTEGER NOT NULL DEFAULT 1
  );
  INSERT INTO sluzby(nazev, jednotka, cena, poradi) VALUES
    ('Renovace ALU kol 12–13"','sada',5900,1),
    ('Renovace ALU kol 14–15"','sada',6500,2),
    ('Renovace ALU kol 16–17"','sada',7200,3),
    ('Renovace ALU kol 18–19"','sada',7900,4),
    ('Renovace ALU kol 20–21"','sada',9500,5),
    ('Renovace ALU kol 22" a více','sada',10800,6),
    ('Odlakování a pískování ALU kol 12–13"','sada',2200,7),
    ('Odlakování a pískování ALU kol 14–15"','sada',2400,8),
    ('Odlakování a pískování ALU kol 16–17"','sada',2600,9),
    ('Odlakování a pískování ALU kol 18–19"','sada',3000,10),
    ('Odlakování a pískování ALU kol 20–21"','sada',4000,11),
    ('Odlakování a pískování ALU kol 22" a více','sada',5000,12),
    ('Rovnání disku','kolo',900,13),
    ('Expres do 24 hodin','sada',5000,14),
    ('Renovace ocelových disků','sada',4000,15);
  CREATE TABLE zakazky (
    id INTEGER PRIMARY KEY,
    cislo TEXT UNIQUE NOT NULL,
    zakaznik_id INTEGER NOT NULL REFERENCES zakaznici(id),
    stav TEXT NOT NULL DEFAULT 'prijato' CHECK (stav IN ('prijato','v_praci','hotovo','predano','zruseno')),
    prijato_dne TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    prevzal TEXT, termin TEXT, informovat TEXT,
    prislusenstvi TEXT, zakryt TEXT,
    vady TEXT NOT NULL DEFAULT '[]', vady_poznamka TEXT, stari_let TEXT, chybi_dily TEXT, fotek INTEGER,
    souhlas_foto INTEGER NOT NULL DEFAULT 0,
    zaloha REAL NOT NULL DEFAULT 0, poznamka TEXT,
    hotovo_dne TEXT, predano_dne TEXT, vyhrada TEXT
  );
  CREATE TABLE zakazky_polozky (
    id INTEGER PRIMARY KEY,
    zakazka_id INTEGER NOT NULL REFERENCES zakazky(id) ON DELETE CASCADE,
    co TEXT NOT NULL, ks REAL NOT NULL DEFAULT 1, material TEXT, prace TEXT, barva TEXT,
    sluzba_id INTEGER REFERENCES sluzby(id), cena REAL NOT NULL DEFAULT 0, poradi INTEGER NOT NULL DEFAULT 0
  );
  CREATE INDEX zakpol_zak ON zakazky_polozky(zakazka_id);
  CREATE INDEX zakazky_zakaznik ON zakazky(zakaznik_id);
  ALTER TABLE pohyby ADD COLUMN zakazka_id INTEGER REFERENCES zakazky(id);
  INSERT OR IGNORE INTO nastaveni(klic, hodnota) VALUES
    ('zakazka_ujednani', 'Co děláme. Zhotovitel provádí povrchovou úpravu (pískování, práškové lakování, renovace povrchu). Neprovádí opravy materiálu ani konstrukce a nezkoumá vnitřní stav věci, její pevnost ani bezpečnost.\n\nStarý a opotřebený materiál. Zákazník byl upozorněn, že u starších, korodovaných, opravovaných nebo litinových či hliníkových odlitků může materiál při vypalování (asi 180–200 °C) uvolňovat plyny, oleje, soli nebo vlhkost. Na povrchu pak mohou vzniknout bublinky, krátery, póry, odlupování nebo barevné odchylky. Takové vady způsobuje stav materiálu, ne práce zhotovitele, a zhotovitel za ně neodpovídá. Zákazník na provedení zakázky přesto trvá.\n\nSváry a předchozí opravy. Lak vadu sváru ani opravy nezpůsobí a neodstraní. Zhotovitel neodpovídá za praskliny, netěsnosti ani pevnost svárů a oprav provedených jinde. Pískování a vypalování mohou takovou vadu zviditelnit; to není vada lakování.\n\nSkryté vady zjištěné při práci. Pískování může odhalit vady, které nebyly vidět (koroze pod lakem, protenčená stěna, praskliny). Zhotovitel zákazníka o zjištěné vadě informuje a domluví se s ním, zda pokračovat. Za poškození, které je důsledkem takové vady, neodpovídá.\n\nNevyzvednutá zakázka. Zhotovitel oznámí dokončení zakázky způsobem uvedeným výše. Zákazník si věc vyzvedne do 14 dní od oznámení. Poté platí skladné {skladne} Kč za každý započatý den. Nevyzvedne-li si zákazník věc do 6 měsíců od oznámení a nereaguje ani na písemnou výzvu s dodatečnou lhůtou 30 dní, je zhotovitel oprávněn věc prodat nebo ekologicky zlikvidovat. Z výtěžku si zhotovitel uhradí cenu zakázky, skladné a náklady prodeje; přebytek vydá zákazníkovi na jeho žádost.\n\nZakrytí ploch. Zhotovitel zakryje jen místa označená v bodě 2. Vrstva práškového laku má obvykle 60–120 µm; za lak na neoznačených dosedacích plochách a závitech zhotovitel neodpovídá.\n\nBarva. Odstín se může mírně lišit od vzorníku, fotky či obrazovky a od dříve lakovaných dílů. U kol a dílů s montáží zákazník po nasazení zkontroluje a dotáhne šrouby; montáž, vyvážení a pneuservis nejsou součástí zakázky, pokud nejsou výslovně sjednány.\n\nPřevzetí a reklamace. Zákazník si věc při výdeji prohlédne. Viditelné vady zapíše do protokolu při výdeji. Vady laku způsobené zhotovitelem reklamuje bez zbytečného odkladu, s tímto protokolem nebo dokladem o zaplacení.\n\nOsobní údaje. Údaje zákazníka slouží jen k vyřízení zakázky, fakturaci a kontaktu a uchovávají se po dobu, kterou ukládá zákon. Fotky slouží jako dokumentace stavu.'),
    ('skladne_kc', ''), ('dph', '21');
  `,
  // 5 — fáze 4: faktury (obecné: údaje firmy se při vystavení zapíšou do faktury natrvalo)
  `
  CREATE TABLE faktury (
    id INTEGER PRIMARY KEY,
    cislo TEXT UNIQUE NOT NULL,
    zakazka_id INTEGER REFERENCES zakazky(id),
    zakaznik_id INTEGER REFERENCES zakaznici(id),
    odberatel TEXT NOT NULL,
    dodavatel TEXT NOT NULL,
    platce_dph INTEGER NOT NULL DEFAULT 1,
    vystaveno TEXT NOT NULL, duzp TEXT NOT NULL, splatnost TEXT NOT NULL,
    zpusob TEXT NOT NULL DEFAULT 'prevod' CHECK (zpusob IN ('prevod','hotove','karta')),
    stav TEXT NOT NULL DEFAULT 'vystavena' CHECK (stav IN ('vystavena','zaplacena','stornovana')),
    zaplaceno_dne TEXT, zaplaceno_jak TEXT,
    zaloha REAL NOT NULL DEFAULT 0,
    poznamka TEXT,
    vytvoreno TEXT NOT NULL DEFAULT (datetime('now','localtime'))
  );
  CREATE TABLE faktury_polozky (
    id INTEGER PRIMARY KEY,
    faktura_id INTEGER NOT NULL REFERENCES faktury(id) ON DELETE CASCADE,
    popis TEXT NOT NULL, mnozstvi REAL NOT NULL DEFAULT 1, jednotka TEXT,
    cena REAL NOT NULL DEFAULT 0, sazba REAL NOT NULL DEFAULT 21, poradi INTEGER NOT NULL DEFAULT 0
  );
  CREATE INDEX fakpol_fak ON faktury_polozky(faktura_id);
  CREATE INDEX faktury_zakazka ON faktury(zakazka_id);
  INSERT OR IGNORE INTO nastaveni(klic, hodnota) VALUES
    ('firma_platce_dph', '1'), ('firma_ucet', ''), ('firma_iban', ''), ('firma_banka', ''), ('firma_rejstrik', ''),
    ('faktura_splatnost', '14'), ('faktura_vystavil', ''), ('faktura_text', 'Děkujeme za Vaši zakázku.');
  `,
  // 6 — fáze 5: peníze (pokladna + náklady + tržby), hodiny, pravidelné platby
  `
  CREATE TABLE penize (
    id INTEGER PRIMARY KEY,
    datum TEXT NOT NULL,
    smer TEXT NOT NULL CHECK (smer IN ('prijem','vydej')),
    castka REAL NOT NULL CHECK (castka > 0),
    zaklad REAL NOT NULL,
    sazba REAL NOT NULL DEFAULT 0,
    kategorie TEXT NOT NULL,
    popis TEXT,
    hotove INTEGER NOT NULL DEFAULT 0,
    faktura_id INTEGER REFERENCES faktury(id),
    zakazka_id INTEGER REFERENCES zakazky(id),
    objednavka_id INTEGER REFERENCES objednavky(id),
    pravidelna_id INTEGER,
    vytvoreno TEXT NOT NULL DEFAULT (datetime('now','localtime'))
  );
  CREATE INDEX penize_datum ON penize(datum);
  CREATE UNIQUE INDEX penize_faktura ON penize(faktura_id) WHERE faktura_id IS NOT NULL;
  CREATE UNIQUE INDEX penize_zaloha ON penize(zakazka_id) WHERE zakazka_id IS NOT NULL AND kategorie = 'zaloha';
  CREATE TABLE hodiny (
    id INTEGER PRIMARY KEY,
    zamestnanec_id INTEGER NOT NULL REFERENCES zamestnanci(id),
    datum TEXT NOT NULL,
    hodin REAL NOT NULL CHECK (hodin > 0 AND hodin <= 24),
    sazba REAL NOT NULL,
    zakazka_id INTEGER REFERENCES zakazky(id),
    popis TEXT,
    vytvoreno TEXT NOT NULL DEFAULT (datetime('now','localtime'))
  );
  CREATE INDEX hodiny_datum ON hodiny(datum);
  CREATE TABLE pravidelne (
    id INTEGER PRIMARY KEY,
    nazev TEXT NOT NULL, castka REAL NOT NULL, sazba REAL NOT NULL DEFAULT 0,
    kategorie TEXT NOT NULL DEFAULT 'najem', hotove INTEGER NOT NULL DEFAULT 0,
    aktivni INTEGER NOT NULL DEFAULT 1
  );
  INSERT OR IGNORE INTO nastaveni(klic, hodnota) VALUES ('pokladna_pocatek', '0'), ('pokladna_pocatek_datum', '');
  `,
  // 7 — soupis vzorových záznamů (ukázka pro prvního uživatele; smažou se jedním tlačítkem)
  `
  CREATE TABLE vzor (tabulka TEXT NOT NULL, radek INTEGER NOT NULL, PRIMARY KEY (tabulka, radek));
  `,
];

export function otevri(soubor) {
  fs.mkdirSync(path.dirname(soubor), { recursive: true });
  const db = new DatabaseSync(soubor);
  db.exec('PRAGMA journal_mode = WAL; PRAGMA busy_timeout = 3000;');
  // Migrace běží s vypnutými cizími klíči (přestavba tabulky polozky), pak se klíče zapnou a zkontrolují.
  db.exec('PRAGMA foreign_keys = OFF;');
  const verze = db.prepare('PRAGMA user_version').get().user_version;
  if (verze > 0 && verze < MIGRACE.length) {
    const kopie = path.join(path.dirname(soubor), `pred-prevodem-v${verze}-${new Date().toISOString().slice(0, 10)}.db`);
    if (!fs.existsSync(kopie)) db.exec(`VACUUM INTO '${kopie.replace(/'/g, "''")}'`);
  }
  for (let i = verze; i < MIGRACE.length; i++) {
    db.exec('BEGIN');
    try {
      db.exec(MIGRACE[i]);
      db.exec(`PRAGMA user_version = ${i + 1}`);
      const vadne = db.prepare('PRAGMA foreign_key_check').all();
      if (vadne.length) throw new Error('Převod dat by porušil vazby: ' + JSON.stringify(vadne.slice(0, 3)));
      db.exec('COMMIT');
    } catch (e) { db.exec('ROLLBACK'); throw e; }
  }
  db.exec('PRAGMA foreign_keys = ON;');
  return db;
}

export function transakce(db, fn) {
  db.exec('BEGIN IMMEDIATE');
  try { const r = fn(); db.exec('COMMIT'); return r; }
  catch (e) { db.exec('ROLLBACK'); throw e; }
}
