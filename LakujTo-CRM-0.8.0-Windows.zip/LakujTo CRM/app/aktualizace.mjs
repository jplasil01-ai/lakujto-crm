// LakujTo CRM — aktualizace z internetu: porovnání verzí, rozbalení zipu (bez cizích knihoven), ověření otisku.
import fs from 'node:fs';
import path from 'node:path';
import zlib from 'node:zlib';
import crypto from 'node:crypto';

// '0.10.0' > '0.9.3'
export function novejsi(a, b) {
  const x = String(a).split('.').map(Number), y = String(b).split('.').map(Number);
  for (let i = 0; i < Math.max(x.length, y.length); i++) {
    const d = (x[i] || 0) - (y[i] || 0);
    if (d) return d > 0;
  }
  return false;
}
export const otisk = (buf) => crypto.createHash('sha256').update(buf).digest('hex');

// Rozbalí zip (uložené nebo deflate položky) do složky. Čte centrální adresář na konci souboru.
// Položku, která by mířila mimo cílovou složku (../), odmítne.
export function rozbalZip(buf, cil) {
  let eocd = -1;
  for (let i = buf.length - 22; i >= Math.max(0, buf.length - 65557); i--) if (buf.readUInt32LE(i) === 0x06054b50) { eocd = i; break; }
  if (eocd < 0) throw new Error('soubor není zip');
  const pocet = buf.readUInt16LE(eocd + 10);
  let p = buf.readUInt32LE(eocd + 16);
  const koren = path.resolve(cil);
  fs.mkdirSync(koren, { recursive: true });
  let souboru = 0;
  for (let n = 0; n < pocet; n++) {
    if (buf.readUInt32LE(p) !== 0x02014b50) throw new Error('poškozený zip (adresář)');
    const metoda = buf.readUInt16LE(p + 10);
    const zabaleno = buf.readUInt32LE(p + 20), velikost = buf.readUInt32LE(p + 24);
    const dJm = buf.readUInt16LE(p + 28), dEx = buf.readUInt16LE(p + 30), dKom = buf.readUInt16LE(p + 32);
    const lokal = buf.readUInt32LE(p + 42);
    const jmeno = buf.toString('utf8', p + 46, p + 46 + dJm);
    p += 46 + dJm + dEx + dKom;
    const kam = path.resolve(koren, jmeno);
    if (kam !== koren && !kam.startsWith(koren + path.sep)) throw new Error('zip míří mimo složku: ' + jmeno);
    if (jmeno.endsWith('/')) { fs.mkdirSync(kam, { recursive: true }); continue; }
    if (buf.readUInt32LE(lokal) !== 0x04034b50) throw new Error('poškozený zip (položka)');
    const start = lokal + 30 + buf.readUInt16LE(lokal + 26) + buf.readUInt16LE(lokal + 28);
    const data = buf.subarray(start, start + zabaleno);
    const obsah = metoda === 0 ? data : metoda === 8 ? zlib.inflateRawSync(data) : null;
    if (!obsah) throw new Error('nepodporovaná komprese v zipu: ' + metoda);
    if (obsah.length !== velikost) throw new Error('poškozený zip (velikost): ' + jmeno);
    fs.mkdirSync(path.dirname(kam), { recursive: true });
    fs.writeFileSync(kam, obsah);
    souboru++;
  }
  return souboru;
}

// Popis aktualizace (aktualizace.json): { verze, zip, sha256, velikost, poznamka, datum }
export async function nactiPopis(url, casMs = 8000) {
  const r = await fetch(url, { signal: AbortSignal.timeout(casMs), cache: 'no-store' });
  if (!r.ok) throw new Error(`server s aktualizacemi odpověděl ${r.status}`);
  const m = await r.json();
  if (!/^\d+\.\d+\.\d+$/.test(m.verze || '') || !m.zip || !/^[0-9a-f]{64}$/.test(m.sha256 || '')) throw new Error('popis aktualizace je neúplný');
  return { ...m, zip: new URL(m.zip, r.url || url).href };
}
