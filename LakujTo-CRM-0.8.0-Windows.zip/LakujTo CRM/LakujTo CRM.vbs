' LakujTo CRM - spusteni programu (server bezi skryte, okno se otevre v Edge jako aplikace)
Option Explicit
Dim sh, fso, dir, url
Set sh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
dir = fso.GetParentFolderName(WScript.ScriptFullName)
url = "http://localhost:8765"
sh.CurrentDirectory = dir
' spusti server (kdyz uz bezi, sam se hned ukonci)
sh.Run """" & dir & "\node\node.exe"" --no-warnings """ & dir & "\app\server.mjs""", 0, False
WScript.Sleep 1500
On Error Resume Next
sh.Run "msedge --app=" & url, 1, False
If Err.Number <> 0 Then
  Err.Clear
  sh.Run url, 1, False
End If
