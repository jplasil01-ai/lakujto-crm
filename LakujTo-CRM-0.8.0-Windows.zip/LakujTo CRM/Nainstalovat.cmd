@echo off
setlocal
set "CIL=%LOCALAPPDATA%\LakujTo CRM"
echo.
echo  Instaluji LakujTo CRM do: %CIL%
echo  (data programu zustanou v Dokumentech ve slozce "LakujTo CRM", instalace je neprepise)
echo.
rem kdyz program bezi, vypni ho (jinak nejdou prepsat soubory)
powershell -NoProfile -Command "try { Invoke-WebRequest -UseBasicParsing -Method Post -TimeoutSec 3 http://localhost:8765/api/konec | Out-Null } catch {}" >nul 2>&1
timeout /t 2 /nobreak >nul
if exist "%CIL%\app" rmdir /s /q "%CIL%\app"
xcopy "%~dp0*" "%CIL%\" /e /i /y /q >nul
if errorlevel 1 (
  echo  CHYBA: kopirovani se nepovedlo. Zavrete program LakujTo CRM a zkuste to znovu.
  pause
  exit /b 1
)
powershell -NoProfile -ExecutionPolicy Bypass -Command "$s=(New-Object -ComObject WScript.Shell).CreateShortcut([Environment]::GetFolderPath('Desktop')+'\LakujTo CRM.lnk'); $s.TargetPath='wscript.exe'; $s.Arguments='\"%CIL%\LakujTo CRM.vbs\"'; $s.IconLocation='%CIL%\logo.ico'; $s.WorkingDirectory='%CIL%'; $s.Description='LakujTo CRM'; $s.Save()"
echo  Hotovo. Na plose je ikona "LakujTo CRM".
echo  Pri prvnim spusteni se Windows muze zeptat, jestli povolit pristup do site.
echo  Kliknete na "Povolit" (soukrome site) - jinak nebude fungovat vazeni z telefonu.
echo.
start "" wscript.exe "%CIL%\LakujTo CRM.vbs"
pause
